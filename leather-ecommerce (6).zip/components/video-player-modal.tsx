"use client"

import { useState, useRef, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { X, Play, Pause, Volume2, VolumeX, Maximize, Minimize, SkipBack, SkipForward } from "lucide-react"
import { cn } from "@/lib/utils"

interface VideoPlayerModalProps {
  isOpen: boolean
  onClose: () => void
  video: {
    id: number
    title: string
    description: string
    videoUrl: string
    duration: string
    views: number
  }
  onNext?: () => void
  onPrevious?: () => void
  hasNext?: boolean
  hasPrevious?: boolean
}

export function VideoPlayerModal({
  isOpen,
  onClose,
  video,
  onNext,
  onPrevious,
  hasNext = false,
  hasPrevious = false,
}: VideoPlayerModalProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [volume, setVolume] = useState(1)
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [showControls, setShowControls] = useState(true)
  const [isLoading, setIsLoading] = useState(true)
  const [isBuffering, setIsBuffering] = useState(false)

  const videoRef = useRef<HTMLVideoElement>(null)
  const modalRef = useRef<HTMLDivElement>(null)
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  // Format time helper
  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60)
    const seconds = Math.floor(time % 60)
    return `${minutes}:${seconds.toString().padStart(2, "0")}`
  }

  // Auto-hide controls
  const resetControlsTimeout = useCallback(() => {
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current)
    }
    setShowControls(true)
    controlsTimeoutRef.current = setTimeout(() => {
      if (isPlaying) {
        setShowControls(false)
      }
    }, 3000)
  }, [isPlaying])

  // Play/Pause functionality
  const togglePlayPause = useCallback(async () => {
    if (!videoRef.current) return

    try {
      if (isPlaying) {
        await videoRef.current.pause()
        setIsPlaying(false)
      } else {
        await videoRef.current.play()
        setIsPlaying(true)
      }
    } catch (error) {
      console.error("Video play/pause error:", error)
    }
  }, [isPlaying])

  // Mute/Unmute functionality
  const toggleMute = useCallback(() => {
    if (!videoRef.current) return

    const newMuted = !isMuted
    videoRef.current.muted = newMuted
    setIsMuted(newMuted)
  }, [isMuted])

  // Volume control
  const handleVolumeChange = useCallback((newVolume: number) => {
    if (!videoRef.current) return

    videoRef.current.volume = newVolume
    setVolume(newVolume)
    setIsMuted(newVolume === 0)
  }, [])

  // Seek functionality
  const handleSeek = useCallback((newTime: number) => {
    if (!videoRef.current) return

    videoRef.current.currentTime = newTime
    setCurrentTime(newTime)
  }, [])

  // Fullscreen functionality
  const toggleFullscreen = useCallback(async () => {
    if (!modalRef.current) return

    try {
      if (!isFullscreen) {
        if (modalRef.current.requestFullscreen) {
          await modalRef.current.requestFullscreen()
        }
      } else {
        if (document.exitFullscreen) {
          await document.exitFullscreen()
        }
      }
    } catch (error) {
      console.error("Fullscreen error:", error)
    }
  }, [isFullscreen])

  // Skip forward/backward
  const skipForward = useCallback(() => {
    if (!videoRef.current) return
    const newTime = Math.min(videoRef.current.currentTime + 10, duration)
    handleSeek(newTime)
  }, [duration, handleSeek])

  const skipBackward = useCallback(() => {
    if (!videoRef.current) return
    const newTime = Math.max(videoRef.current.currentTime - 10, 0)
    handleSeek(newTime)
  }, [handleSeek])

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (!isOpen) return

      switch (event.key) {
        case "Escape":
          onClose()
          break
        case " ":
        case "k":
          event.preventDefault()
          togglePlayPause()
          break
        case "m":
          toggleMute()
          break
        case "f":
          toggleFullscreen()
          break
        case "ArrowLeft":
          event.preventDefault()
          skipBackward()
          break
        case "ArrowRight":
          event.preventDefault()
          skipForward()
          break
        case "ArrowUp":
          event.preventDefault()
          handleVolumeChange(Math.min(volume + 0.1, 1))
          break
        case "ArrowDown":
          event.preventDefault()
          handleVolumeChange(Math.max(volume - 0.1, 0))
          break
        case "0":
        case "1":
        case "2":
        case "3":
        case "4":
        case "5":
        case "6":
        case "7":
        case "8":
        case "9":
          event.preventDefault()
          const percentage = Number.parseInt(event.key) / 10
          handleSeek(duration * percentage)
          break
      }
    }

    document.addEventListener("keydown", handleKeyDown)
    return () => document.removeEventListener("keydown", handleKeyDown)
  }, [
    isOpen,
    onClose,
    togglePlayPause,
    toggleMute,
    toggleFullscreen,
    skipBackward,
    skipForward,
    handleVolumeChange,
    handleSeek,
    volume,
    duration,
  ])

  // Video event handlers
  useEffect(() => {
    const video = videoRef.current
    if (!video) return

    const handleLoadedMetadata = () => {
      setDuration(video.duration)
      setIsLoading(false)
    }

    const handleTimeUpdate = () => {
      setCurrentTime(video.currentTime)
    }

    const handlePlay = () => {
      setIsPlaying(true)
      setIsBuffering(false)
    }

    const handlePause = () => {
      setIsPlaying(false)
    }

    const handleWaiting = () => {
      setIsBuffering(true)
    }

    const handleCanPlay = () => {
      setIsBuffering(false)
    }

    const handleEnded = () => {
      setIsPlaying(false)
      if (hasNext && onNext) {
        onNext()
      }
    }

    video.addEventListener("loadedmetadata", handleLoadedMetadata)
    video.addEventListener("timeupdate", handleTimeUpdate)
    video.addEventListener("play", handlePlay)
    video.addEventListener("pause", handlePause)
    video.addEventListener("waiting", handleWaiting)
    video.addEventListener("canplay", handleCanPlay)
    video.addEventListener("ended", handleEnded)

    return () => {
      video.removeEventListener("loadedmetadata", handleLoadedMetadata)
      video.removeEventListener("timeupdate", handleTimeUpdate)
      video.removeEventListener("play", handlePlay)
      video.removeEventListener("pause", handlePause)
      video.removeEventListener("waiting", handleWaiting)
      video.removeEventListener("canplay", handleCanPlay)
      video.removeEventListener("ended", handleEnded)
    }
  }, [hasNext, onNext])

  // Fullscreen change handler
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }

    document.addEventListener("fullscreenchange", handleFullscreenChange)
    return () => document.removeEventListener("fullscreenchange", handleFullscreenChange)
  }, [])

  // Mouse movement handler for controls
  useEffect(() => {
    if (!isOpen) return

    const handleMouseMove = () => {
      resetControlsTimeout()
    }

    const handleMouseLeave = () => {
      if (isPlaying) {
        setShowControls(false)
      }
    }

    document.addEventListener("mousemove", handleMouseMove)
    modalRef.current?.addEventListener("mouseleave", handleMouseLeave)

    return () => {
      document.removeEventListener("mousemove", handleMouseMove)
      modalRef.current?.removeEventListener("mouseleave", handleMouseLeave)
    }
  }, [isOpen, isPlaying, resetControlsTimeout])

  // Reset state when modal opens/closes
  useEffect(() => {
    if (isOpen) {
      setIsLoading(true)
      setCurrentTime(0)
      setIsPlaying(false)
      setShowControls(true)
    } else {
      // Pause video when modal closes
      if (videoRef.current) {
        videoRef.current.pause()
      }
      setIsPlaying(false)
    }
  }, [isOpen])

  // Prevent body scroll when modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = "unset"
    }

    return () => {
      document.body.style.overflow = "unset"
    }
  }, [isOpen])

  if (!isOpen) return null

  return (
    <div
      ref={modalRef}
      className="fixed inset-0 z-50 bg-black flex items-center justify-center"
      onClick={(e) => {
        if (e.target === modalRef.current) {
          onClose()
        }
      }}
    >
      {/* Video Container */}
      <div className="relative w-full h-full flex items-center justify-center">
        {/* Loading Spinner */}
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-16 h-16 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
          </div>
        )}

        {/* Buffering Indicator */}
        {isBuffering && !isLoading && (
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20">
            <div className="w-12 h-12 border-4 border-white border-t-transparent rounded-full animate-spin"></div>
          </div>
        )}

        {/* Video Element */}
        <video
          ref={videoRef}
          className="w-full h-full object-contain"
          src={video.videoUrl}
          onClick={togglePlayPause}
          onDoubleClick={toggleFullscreen}
        />

        {/* Controls Overlay */}
        <div
          className={cn(
            "absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/60 transition-opacity duration-300",
            showControls ? "opacity-100" : "opacity-0",
          )}
        >
          {/* Top Controls */}
          <div className="absolute top-0 left-0 right-0 p-4 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h2 className="text-white text-xl font-semibold">{video.title}</h2>
              <Badge variant="secondary" className="text-xs">
                {video.views.toLocaleString()} görüntüleme
              </Badge>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose} className="text-white hover:bg-white/20">
              <X className="h-6 w-6" />
            </Button>
          </div>

          {/* Center Play/Pause Button */}
          {!isLoading && (
            <div className="absolute inset-0 flex items-center justify-center">
              <Button
                variant="ghost"
                size="icon"
                onClick={togglePlayPause}
                className="w-20 h-20 rounded-full bg-black/50 hover:bg-black/70 text-white"
              >
                {isPlaying ? <Pause className="h-10 w-10" /> : <Play className="h-10 w-10 ml-1" />}
              </Button>
            </div>
          )}

          {/* Bottom Controls */}
          <div className="absolute bottom-0 left-0 right-0 p-4 space-y-4">
            {/* Progress Bar */}
            <div className="flex items-center gap-2 text-white text-sm">
              <span>{formatTime(currentTime)}</span>
              <div className="flex-1 relative">
                <input
                  type="range"
                  min={0}
                  max={duration || 0}
                  value={currentTime}
                  onChange={(e) => handleSeek(Number(e.target.value))}
                  className="w-full h-2 bg-white/30 rounded-lg appearance-none cursor-pointer slider"
                />
                <div
                  className="absolute top-0 left-0 h-2 bg-red-600 rounded-lg pointer-events-none"
                  style={{ width: `${duration ? (currentTime / duration) * 100 : 0}%` }}
                />
              </div>
              <span>{formatTime(duration)}</span>
            </div>

            {/* Control Buttons */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {/* Previous Video */}
                {hasPrevious && (
                  <Button variant="ghost" size="icon" onClick={onPrevious} className="text-white hover:bg-white/20">
                    <SkipBack className="h-5 w-5" />
                  </Button>
                )}

                {/* Skip Backward */}
                <Button variant="ghost" size="icon" onClick={skipBackward} className="text-white hover:bg-white/20">
                  <SkipBack className="h-4 w-4" />
                  <span className="text-xs ml-1">10s</span>
                </Button>

                {/* Play/Pause */}
                <Button variant="ghost" size="icon" onClick={togglePlayPause} className="text-white hover:bg-white/20">
                  {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                </Button>

                {/* Skip Forward */}
                <Button variant="ghost" size="icon" onClick={skipForward} className="text-white hover:bg-white/20">
                  <span className="text-xs mr-1">10s</span>
                  <SkipForward className="h-4 w-4" />
                </Button>

                {/* Next Video */}
                {hasNext && (
                  <Button variant="ghost" size="icon" onClick={onNext} className="text-white hover:bg-white/20">
                    <SkipForward className="h-5 w-5" />
                  </Button>
                )}

                {/* Volume Controls */}
                <div className="flex items-center gap-2 ml-4">
                  <Button variant="ghost" size="icon" onClick={toggleMute} className="text-white hover:bg-white/20">
                    {isMuted || volume === 0 ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                  </Button>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.1}
                    value={isMuted ? 0 : volume}
                    onChange={(e) => handleVolumeChange(Number(e.target.value))}
                    className="w-20 h-1 bg-white/30 rounded-lg appearance-none cursor-pointer slider"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2">
                {/* Fullscreen */}
                <Button variant="ghost" size="icon" onClick={toggleFullscreen} className="text-white hover:bg-white/20">
                  {isFullscreen ? <Minimize className="h-5 w-5" /> : <Maximize className="h-5 w-5" />}
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Video Description */}
        {showControls && (
          <div className="absolute bottom-20 left-4 right-4 text-white">
            <p className="text-sm opacity-80 max-w-2xl">{video.description}</p>
          </div>
        )}
      </div>

      {/* Keyboard Shortcuts Help */}
      {showControls && (
        <div className="absolute top-20 right-4 bg-black/70 backdrop-blur-sm text-white p-3 rounded-lg text-xs space-y-1">
          <p className="font-semibold mb-2">Klavye Kısayolları:</p>
          <p>Space/K: Oynat/Duraklat</p>
          <p>M: Ses Aç/Kapat</p>
          <p>F: Tam Ekran</p>
          <p>←/→: 10s Geri/İleri</p>
          <p>↑/↓: Ses Seviyesi</p>
          <p>0-9: Video Konumu</p>
          <p>ESC: Kapat</p>
        </div>
      )}
    </div>
  )
}
