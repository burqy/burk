"use client"

import { createContext, useContext, useReducer, useEffect, type ReactNode } from "react"

type Language = "tr" | "en"
type Currency = "TRY" | "USD"

interface LanguageState {
  language: Language
  currency: Currency
}

interface LanguageContextType extends LanguageState {
  setLanguage: (language: Language) => void
  t: (key: string) => string
  formatPrice: (price: number) => string
  convertPrice: (price: number) => number
}

const LanguageContext = createContext<LanguageContextType | null>(null)

// Exchange rate (in real app, this would come from an API)
const EXCHANGE_RATE = 0.037 // 1 TRY = 0.037 USD (approximate)

// Translations
const translations = {
  tr: {
    // Header
    "header.allProducts": "Tüm Ürünler",
    "header.bags": "Çantalar",
    "header.wallets": "Cüzdanlar",
    "header.cardHolders": "Kart Tutucular",
    "header.accessories": "Aksesuarlar",
    "header.digitalProducts": "Dijital Ürünler",
    "header.marketplace": "Pazaryeri",
    "header.gallery": "Galeri",
    "header.search": "Ürün ara...",
    "header.cart": "Alışveriş Sepeti",
    "header.cartEmpty": "Sepetiniz boş",
    "header.cartItems": "Sepetinizde {count} ürün var",
    "header.noItems": "Sepette ürün yok",
    "header.checkout": "Ödemeye Geç",
    "header.login": "Giriş",
    "header.register": "Üye Ol",
    "header.profile": "Profilim",
    "header.orders": "Siparişlerim",
    "header.digitalProducts": "Dijital Ürünlerim",
    "header.points": "Puanlarım",
    "header.logout": "Çıkış Yap",
    "header.menu": "Menü",

    // Product related
    "product.addToCart": "Sepete Ekle",
    "product.viewDetails": "Detayları Gör",
    "product.digital": "Dijital",
    "product.physical": "Fiziksel",
    "product.color": "Renk",
    "product.ropeColor": "İp Rengi",
    "product.giftWrap": "Hediye Paketi",
    "product.price": "Fiyat",
    "product.total": "Toplam",

    // Cart
    "cart.color": "Renk",
    "cart.ropeColor": "İp Rengi",
    "cart.quantity": "Adet",

    // Common
    "common.loading": "Yükleniyor...",
    "common.save": "Kaydet",
    "common.cancel": "İptal",
    "common.delete": "Sil",
    "common.edit": "Düzenle",
    "common.close": "Kapat",
    "common.submit": "Gönder",
    "common.search": "Ara",
    "common.filter": "Filtrele",
    "common.sort": "Sırala",

    // Membership tiers
    "membership.bronze": "Bronz",
    "membership.silver": "Gümüş",
    "membership.gold": "Altın",
    "membership.platinum": "Platin",

    // Language
    "language.turkish": "Türkçe",
    "language.english": "English",

    // Homepage
    "homepage.featuredProducts": "Öne Çıkan Ürünler",
    "homepage.featuredProductsDesc": "En popüler deri ürünlerimizi ve dijital kaynaklarımızı keşfedin",
    "homepage.leatherVideos": "Deri Sanatı Videoları",
    "homepage.leatherVideosDesc": "Deri işçiliğinin inceliklerini ve atölyemizdeki çalışmaları videolarımızla keşfedin",
    "homepage.watchAllVideos": "Tüm Videoları İzle",
    "homepage.shopByCategory": "Kategoriye Göre Alışveriş",
    "homepage.leatherBags": "Deri Çantalar",
    "homepage.leatherBagsDesc": "Her duruma uygun el yapımı çantalar",
    "homepage.accessories": "Aksesuarlar",
    "homepage.accessoriesDesc": "Cüzdanlar, kemerler ve daha fazlası",
    "homepage.digitalGuides": "Dijital Rehberler",
    "homepage.digitalGuidesDesc": "Uzman PDF rehberleri ve eğitimleri",
    "homepage.ourCraft": "Deri Sanatımız",
    "homepage.ourCraftSubtitle": "Geleneksel zanaatkarlık ile modern tasarımın buluştuğu nokta",
    "homepage.discoverStory": "Hikayemizi Keşfedin",
    "homepage.views": "görüntüleme",
  },
  en: {
    // Header
    "header.allProducts": "All Products",
    "header.bags": "Bags",
    "header.wallets": "Wallets",
    "header.cardHolders": "Card Holders",
    "header.accessories": "Accessories",
    "header.digitalProducts": "Digital Products",
    "header.marketplace": "Marketplace",
    "header.gallery": "Gallery",
    "header.search": "Search products...",
    "header.cart": "Shopping Cart",
    "header.cartEmpty": "Your cart is empty",
    "header.cartItems": "You have {count} items in your cart",
    "header.noItems": "No items in cart",
    "header.checkout": "Checkout",
    "header.login": "Login",
    "header.register": "Sign Up",
    "header.profile": "My Profile",
    "header.orders": "My Orders",
    "header.digitalProducts": "My Digital Products",
    "header.points": "My Points",
    "header.logout": "Logout",
    "header.menu": "Menu",

    // Product related
    "product.addToCart": "Add to Cart",
    "product.viewDetails": "View Details",
    "product.digital": "Digital",
    "product.physical": "Physical",
    "product.color": "Color",
    "product.ropeColor": "Rope Color",
    "product.giftWrap": "Gift Wrap",
    "product.price": "Price",
    "product.total": "Total",

    // Cart
    "cart.color": "Color",
    "cart.ropeColor": "Rope Color",
    "cart.quantity": "Qty",

    // Common
    "common.loading": "Loading...",
    "common.save": "Save",
    "common.cancel": "Cancel",
    "common.delete": "Delete",
    "common.edit": "Edit",
    "common.close": "Close",
    "common.submit": "Submit",
    "common.search": "Search",
    "common.filter": "Filter",
    "common.sort": "Sort",

    // Membership tiers
    "membership.bronze": "Bronze",
    "membership.silver": "Silver",
    "membership.gold": "Gold",
    "membership.platinum": "Platinum",

    // Language
    "language.turkish": "Türkçe",
    "language.english": "English",

    // Homepage
    "homepage.featuredProducts": "Featured Products",
    "homepage.featuredProductsDesc": "Discover our most popular leather products and digital resources",
    "homepage.leatherVideos": "Leather Craft Videos",
    "homepage.leatherVideosDesc":
      "Explore the intricacies of leather craftsmanship and our workshop activities through our videos",
    "homepage.watchAllVideos": "Watch All Videos",
    "homepage.shopByCategory": "Shop by Category",
    "homepage.leatherBags": "Leather Bags",
    "homepage.leatherBagsDesc": "Handmade bags for every occasion",
    "homepage.accessories": "Accessories",
    "homepage.accessoriesDesc": "Wallets, belts and more",
    "homepage.digitalGuides": "Digital Guides",
    "homepage.digitalGuidesDesc": "Expert PDF guides and tutorials",
    "homepage.ourCraft": "Our Leather Craft",
    "homepage.ourCraftSubtitle": "Where traditional craftsmanship meets modern design",
    "homepage.discoverStory": "Discover Our Story",
    "homepage.views": "views",
  },
}

type LanguageAction = { type: "SET_LANGUAGE"; payload: Language }

function languageReducer(state: LanguageState, action: LanguageAction): LanguageState {
  switch (action.type) {
    case "SET_LANGUAGE":
      return {
        language: action.payload,
        currency: action.payload === "tr" ? "TRY" : "USD",
      }
    default:
      return state
  }
}

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(languageReducer, {
    language: "tr",
    currency: "TRY",
  })

  // Load language from localStorage on mount
  useEffect(() => {
    const savedLanguage = localStorage.getItem("language") as Language
    if (savedLanguage && (savedLanguage === "tr" || savedLanguage === "en")) {
      dispatch({ type: "SET_LANGUAGE", payload: savedLanguage })
    }
  }, [])

  const setLanguage = (language: Language) => {
    dispatch({ type: "SET_LANGUAGE", payload: language })
    localStorage.setItem("language", language)
  }

  const t = (key: string, params?: Record<string, string | number>) => {
    let translation = translations[state.language][key as keyof (typeof translations)[typeof state.language]] || key

    // Replace parameters in translation
    if (params) {
      Object.entries(params).forEach(([paramKey, value]) => {
        translation = translation.replace(`{${paramKey}}`, String(value))
      })
    }

    return translation
  }

  const convertPrice = (price: number): number => {
    if (state.currency === "USD") {
      return Math.round(price * EXCHANGE_RATE * 100) / 100 // Round to 2 decimal places
    }
    return price
  }

  const formatPrice = (price: number): string => {
    const convertedPrice = convertPrice(price)
    const symbol = state.currency === "TRY" ? "₺" : "$"

    if (state.currency === "USD") {
      return `${symbol}${convertedPrice.toFixed(2)}`
    }
    return `${symbol}${convertedPrice.toFixed(2)}`
  }

  return (
    <LanguageContext.Provider
      value={{
        ...state,
        setLanguage,
        t,
        formatPrice,
        convertPrice,
      }}
    >
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
