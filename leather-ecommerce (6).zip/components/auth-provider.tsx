"use client"

import { createContext, useContext, useReducer, useEffect, type ReactNode } from "react"

interface User {
  id: string
  email: string
  firstName: string
  lastName: string
  phone?: string
  birthDate?: string
  gender?: string
  city?: string
  district?: string
  address?: string
  membershipTier: "bronze" | "silver" | "gold" | "platinum"
  totalSpent: number
  orderCount: number
  joinDate: string
  isEmailVerified: boolean
  acceptsMarketing: boolean
  loyaltyPoints: number
}

interface AuthState {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
}

type AuthAction =
  | { type: "SET_USER"; payload: User }
  | { type: "CLEAR_USER" }
  | { type: "SET_LOADING"; payload: boolean }
  | { type: "UPDATE_USER"; payload: Partial<User> }

const AuthContext = createContext<{
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  login: (email: string, password: string, rememberMe?: boolean) => Promise<boolean>
  register: (userData: any, acceptsMarketing: boolean) => Promise<boolean>
  logout: () => void
  updateProfile: (data: Partial<User>) => Promise<boolean>
  updateMembershipTier: () => void
} | null>(null)

// Mock users database
const mockUsers: User[] = [
  {
    id: "1",
    email: "test@example.com",
    firstName: "Ahmet",
    lastName: "Yılmaz",
    phone: "0555 123 45 67",
    membershipTier: "gold",
    totalSpent: 1250.5,
    orderCount: 3,
    joinDate: "2023-01-15",
    isEmailVerified: true,
    acceptsMarketing: true,
    loyaltyPoints: 1250,
    city: "İstanbul",
    district: "Kadıköy",
  },
]

function authReducer(state: AuthState, action: AuthAction): AuthState {
  switch (action.type) {
    case "SET_USER":
      return {
        ...state,
        user: action.payload,
        isAuthenticated: true,
        isLoading: false,
      }
    case "CLEAR_USER":
      return {
        ...state,
        user: null,
        isAuthenticated: false,
        isLoading: false,
      }
    case "SET_LOADING":
      return {
        ...state,
        isLoading: action.payload,
      }
    case "UPDATE_USER":
      return {
        ...state,
        user: state.user ? { ...state.user, ...action.payload } : null,
      }
    default:
      return state
  }
}

function calculateMembershipTier(totalSpent: number): "bronze" | "silver" | "gold" | "platinum" {
  if (totalSpent >= 5000) return "platinum"
  if (totalSpent >= 2000) return "gold"
  if (totalSpent >= 500) return "silver"
  return "bronze"
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(authReducer, {
    user: null,
    isAuthenticated: false,
    isLoading: true,
  })

  useEffect(() => {
    // Check for stored user session
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      try {
        const user = JSON.parse(storedUser)
        dispatch({ type: "SET_USER", payload: user })
      } catch (error) {
        localStorage.removeItem("user")
      }
    }
    dispatch({ type: "SET_LOADING", payload: false })
  }, [])

  const login = async (email: string, password: string, rememberMe = false): Promise<boolean> => {
    // Mock authentication
    const user = mockUsers.find((u) => u.email === email)
    if (user && password === "123456") {
      dispatch({ type: "SET_USER", payload: user })
      if (rememberMe) {
        localStorage.setItem("user", JSON.stringify(user))
      }
      return true
    }
    return false
  }

  const register = async (userData: any, acceptsMarketing: boolean): Promise<boolean> => {
    // Check if email already exists
    const existingUser = mockUsers.find((u) => u.email === userData.email)
    if (existingUser) {
      return false
    }

    // Create new user
    const newUser: User = {
      id: Date.now().toString(),
      email: userData.email,
      firstName: userData.firstName,
      lastName: userData.lastName,
      phone: userData.phone,
      birthDate: userData.birthDate,
      gender: userData.gender,
      city: userData.city,
      district: userData.district,
      address: userData.address,
      membershipTier: "bronze",
      totalSpent: 0,
      orderCount: 0,
      joinDate: new Date().toISOString().split("T")[0],
      isEmailVerified: false,
      acceptsMarketing,
      loyaltyPoints: 0,
    }

    mockUsers.push(newUser)
    dispatch({ type: "SET_USER", payload: newUser })
    localStorage.setItem("user", JSON.stringify(newUser))
    return true
  }

  const logout = () => {
    dispatch({ type: "CLEAR_USER" })
    localStorage.removeItem("user")
  }

  const updateProfile = async (data: Partial<User>): Promise<boolean> => {
    if (!state.user) return false

    const updatedUser = { ...state.user, ...data }
    dispatch({ type: "UPDATE_USER", payload: data })
    localStorage.setItem("user", JSON.stringify(updatedUser))
    return true
  }

  const updateMembershipTier = () => {
    if (!state.user) return

    const newTier = calculateMembershipTier(state.user.totalSpent)
    if (newTier !== state.user.membershipTier) {
      dispatch({ type: "UPDATE_USER", payload: { membershipTier: newTier } })
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user: state.user,
        isAuthenticated: state.isAuthenticated,
        isLoading: state.isLoading,
        login,
        register,
        logout,
        updateProfile,
        updateMembershipTier,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
