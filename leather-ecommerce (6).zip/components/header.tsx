"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ShoppingCart, Menu, Search, Gift, User, LogOut, Camera, Store, Globe } from "lucide-react"
import { useState } from "react"
import { useCart } from "@/components/cart-provider"
import { useAuth } from "@/components/auth-provider"
import { useLanguage } from "@/components/language-provider"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const { items } = useCart()
  const { user, isAuthenticated, logout } = useAuth()
  const { language, setLanguage, t, formatPrice } = useLanguage()
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0)

  const membershipTiers = {
    bronze: { name: t("membership.bronze"), color: "bg-amber-600" },
    silver: { name: t("membership.silver"), color: "bg-gray-400" },
    gold: { name: t("membership.gold"), color: "bg-yellow-500" },
    platinum: { name: t("membership.platinum"), color: "bg-purple-600" },
  }

  const cartTotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0)

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-6">
            <Link href="/" className="flex items-center space-x-2" aria-label="DeriSanat - Ana Sayfa">
              <span className="text-2xl font-bold">DeriSanat</span>
            </Link>

            <nav className="hidden md:flex items-center space-x-6" aria-label="Ana Navigasyon">
              <Link href="/products" className="text-sm font-medium hover:text-primary">
                {t("header.allProducts")}
              </Link>
              <Link href="/products?category=çantalar" className="text-sm font-medium hover:text-primary">
                {t("header.bags")}
              </Link>
              <Link href="/products?category=cüzdanlar" className="text-sm font-medium hover:text-primary">
                {t("header.wallets")}
              </Link>
              <Link href="/products?category=kart-tutucular" className="text-sm font-medium hover:text-primary">
                {t("header.cardHolders")}
              </Link>
              <Link href="/products?category=aksesuarlar" className="text-sm font-medium hover:text-primary">
                {t("header.accessories")}
              </Link>
              <Link href="/digital" className="text-sm font-medium hover:text-primary">
                {t("header.digitalProducts")}
              </Link>
              <Link href="/marketplace" className="text-sm font-medium hover:text-primary flex items-center gap-1">
                <Store className="h-4 w-4" />
                {t("header.marketplace")}
              </Link>
              {isAuthenticated && (
                <Link href="/gallery" className="text-sm font-medium hover:text-primary flex items-center gap-1">
                  <Camera className="h-4 w-4" />
                  {t("header.gallery")}
                </Link>
              )}
            </nav>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-2">
              <Search className="h-4 w-4 text-gray-400" />
              <Input
                type="search"
                placeholder={t("header.search")}
                className="w-64"
                aria-label={t("header.searchAriaLabel")}
              />
            </div>

            {/* Language Switcher */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="icon" aria-label={t("header.languageSwitcher")}>
                  <Globe className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem
                  onClick={() => setLanguage("tr")}
                  className={language === "tr" ? "bg-accent" : ""}
                  aria-current={language === "tr" ? "true" : "false"}
                >
                  🇹🇷 {t("language.turkish")}
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => setLanguage("en")}
                  className={language === "en" ? "bg-accent" : ""}
                  aria-current={language === "en" ? "true" : "false"}
                >
                  🇺🇸 {t("language.english")}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="relative" aria-label={t("header.shoppingCart")}>
                  <ShoppingCart className="h-4 w-4" />
                  {itemCount > 0 && (
                    <Badge
                      className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs"
                      aria-label={t("header.itemCount", { count: itemCount })}
                    >
                      {itemCount}
                    </Badge>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent>
                <SheetHeader>
                  <SheetTitle>{t("header.cart")}</SheetTitle>
                  <SheetDescription>
                    {itemCount === 0 ? t("header.cartEmpty") : t("header.cartItems", { count: itemCount })}
                  </SheetDescription>
                </SheetHeader>
                <div className="mt-6">
                  {items.length === 0 ? (
                    <p className="text-center text-gray-500 py-8">{t("header.noItems")}</p>
                  ) : (
                    <div className="space-y-4">
                      {items.map((item, index) => (
                        <div key={`${item.id}-${index}`} className="flex items-center gap-3 p-3 border rounded-lg">
                          <div className="flex-1">
                            <h4 className="font-medium">{item.name}</h4>
                            <div className="text-xs text-gray-500 space-y-1">
                              {item.selectedColor && (
                                <p>
                                  {t("cart.color")}: {item.selectedColor}
                                </p>
                              )}
                              {item.selectedRopeColor && (
                                <p>
                                  {t("cart.ropeColor")}: {item.selectedRopeColor}
                                </p>
                              )}
                              {item.isGift && item.giftWrapping && (
                                <div className="flex items-center gap-1">
                                  <Gift className="h-3 w-3" />
                                  <span>{item.giftWrapping.name}</span>
                                </div>
                              )}
                            </div>
                            <p className="text-sm text-gray-600">
                              {formatPrice(item.price)} x {item.quantity}
                            </p>
                          </div>
                        </div>
                      ))}
                      <div className="pt-4 border-t space-y-2">
                        <div className="flex justify-between font-medium">
                          <span>{t("product.total")}:</span>
                          <span>{formatPrice(cartTotal)}</span>
                        </div>
                        <Button className="w-full" asChild>
                          <Link href="/checkout">{t("header.checkout")}</Link>
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </SheetContent>
            </Sheet>

            {/* User Menu */}
            {isAuthenticated && user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="icon" className="relative" aria-label={t("header.userMenu")}>
                    <User className="h-4 w-4" />
                    {user.membershipTier !== "bronze" && (
                      <Badge
                        className={`absolute -top-1 -right-1 h-3 w-3 rounded-full p-0 ${membershipTiers[user.membershipTier].color}`}
                        aria-label={t("membership.level", { level: membershipTiers[user.membershipTier].name })}
                      />
                    )}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <div className="px-2 py-1.5">
                    <p className="text-sm font-medium">
                      {user.firstName} {user.lastName}
                    </p>
                    <div className="flex items-center gap-2">
                      <Badge className={`${membershipTiers[user.membershipTier].color} text-white text-xs`}>
                        {membershipTiers[user.membershipTier].name}
                      </Badge>
                      <span className="text-xs text-gray-600">
                        {user.loyaltyPoints} {language === "en" ? "points" : "puan"}
                      </span>
                    </div>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link href="/profile">{t("header.profile")}</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/profile?tab=orders">{t("header.orders")}</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/profile?tab=digital">{t("header.digitalProducts")}</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/marketplace">
                      <Store className="mr-2 h-4 w-4" />
                      {t("header.marketplace")}
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/gallery">
                      <Camera className="mr-2 h-4 w-4" />
                      {t("header.gallery")}
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/profile?tab=loyalty">{t("header.points")}</Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={logout} className="text-red-600" aria-label={t("header.logoutAriaLabel")}>
                    <LogOut className="mr-2 h-4 w-4" />
                    {t("header.logout")}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="hidden md:flex items-center gap-2">
                <Button variant="outline" size="sm" asChild>
                  <Link href="/auth/login">{t("header.login")}</Link>
                </Button>
                <Button size="sm" asChild>
                  <Link href="/auth/register">{t("header.register")}</Link>
                </Button>
              </div>
            )}

            <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="md:hidden" aria-label={t("header.mobileMenu")}>
                  <Menu className="h-4 w-4" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left">
                <SheetHeader>
                  <SheetTitle>{t("header.menu")}</SheetTitle>
                </SheetHeader>
                <nav className="flex flex-col space-y-4 mt-6" aria-label={t("header.mobileNavigation")}>
                  {!isAuthenticated && (
                    <>
                      <Link href="/auth/login" className="text-sm font-medium" onClick={() => setIsMenuOpen(false)}>
                        {t("header.login")}
                      </Link>
                      <Link href="/auth/register" className="text-sm font-medium" onClick={() => setIsMenuOpen(false)}>
                        {t("header.register")}
                      </Link>
                      <div className="border-t pt-4" />
                    </>
                  )}
                  <Link href="/products" className="text-sm font-medium" onClick={() => setIsMenuOpen(false)}>
                    {t("header.allProducts")}
                  </Link>
                  <Link
                    href="/products?category=çantalar"
                    className="text-sm font-medium"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {t("header.bags")}
                  </Link>
                  <Link
                    href="/products?category=cüzdanlar"
                    className="text-sm font-medium"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {t("header.wallets")}
                  </Link>
                  <Link
                    href="/products?category=kart-tutucular"
                    className="text-sm font-medium"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {t("header.cardHolders")}
                  </Link>
                  <Link
                    href="/products?category=aksesuarlar"
                    className="text-sm font-medium"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {t("header.accessories")}
                  </Link>
                  <Link href="/digital" className="text-sm font-medium" onClick={() => setIsMenuOpen(false)}>
                    {t("header.digitalProducts")}
                  </Link>
                  <Link
                    href="/marketplace"
                    className="text-sm font-medium flex items-center gap-2"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <Store className="h-4 w-4" />
                    {t("header.marketplace")}
                  </Link>
                  {isAuthenticated && (
                    <>
                      <div className="border-t pt-4" />
                      <Link
                        href="/gallery"
                        className="text-sm font-medium flex items-center gap-2"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        <Camera className="h-4 w-4" />
                        {t("header.gallery")}
                      </Link>
                      <Link href="/profile" className="text-sm font-medium" onClick={() => setIsMenuOpen(false)}>
                        {t("header.profile")}
                      </Link>
                      <button
                        onClick={logout}
                        className="text-sm font-medium text-red-600 text-left"
                        aria-label={t("header.logoutAriaLabel")}
                      >
                        {t("header.logout")}
                      </button>
                    </>
                  )}
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  )
}
