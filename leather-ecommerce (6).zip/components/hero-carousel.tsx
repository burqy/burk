"use client"

import type React from "react"

import { useState, useEffect, useRef, useCallback } from "react"
import { cn } from "@/lib/utils"
import { useLanguage } from "@/components/language-provider"

interface CarouselItem {
  id: number
  type: "image" | "video"
  src: string
  thumbnailSrc?: string // Low-res thumbnail or poster image
  alt?: string
  title: string
  description: string
  buttonText: string
  buttonLink: string
}

interface HeroCarouselProps {
  items: CarouselItem[]
  autoPlayInterval?: number
}

export function HeroCarousel({ items, autoPlayInterval = 5000 }: HeroCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isPlaying, setIsPlaying] = useState(true)
  const [isVideoPlaying, setIsVideoPlaying] = useState(false)
  const [isUserInteracting, setIsUserInteracting] = useState(false)
  const [loadedMedia, setLoadedMedia] = useState<Record<number, boolean>>({})
  const [visibleSlides, setVisibleSlides] = useState<number[]>([0]) // Start with first slide
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [modalImageIndex, setModalImageIndex] = useState(0)
  const [isModalImageLoading, setIsModalImageLoading] = useState(true)
  const videoRefs = useRef<(HTMLVideoElement | null)[]>([])
  const slideRefs = useRef<(HTMLDivElement | null)[]>([])
  const autoPlayRef = useRef<NodeJS.Timeout | null>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const modalRef = useRef<HTMLDivElement>(null)
  
  const { t } = useLanguage()

  // Preload adjacent slides (current, prev, next)
  const updateVisibleSlides = useCallback(() => {
    const newVisibleSlides = [currentIndex]

    // Add previous slide
    const prevIndex = currentIndex === 0 ? items.length - 1 : currentIndex - 1
    if (!newVisibleSlides.includes(prevIndex)) {
      newVisibleSlides.push(prevIndex)
    }

    // Add next slide
    const nextIndex = currentIndex === items.length - 1 ? 0 : currentIndex + 1
    if (!newVisibleSlides.includes(nextIndex)) {
      newVisibleSlides.push(nextIndex)
    }

    setVisibleSlides(newVisibleSlides)
  }, [currentIndex, items.length])

  useEffect(() => {
    updateVisibleSlides()
  }, [currentIndex, updateVisibleSlides])

  const goToNext = useCallback(() => {
    setCurrentIndex((prevIndex) => (prevIndex === items.length - 1 ? 0 : prevIndex + 1))
  }, [items.length])

  const goToPrevious = () => {
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? items.length - 1 : prevIndex - 1))
  }

  const goToSlide = (index: number) => {
    setCurrentIndex(index)
  }

  // Modal navigation functions
  const goToNextModalImage = () => {
    const imageItems = items.filter((item) => item.type === "image")
    const currentImageIndex = imageItems.findIndex((_, idx) => idx === modalImageIndex)
    const nextIndex = currentImageIndex === imageItems.length - 1 ? 0 : currentImageIndex + 1
    setModalImageIndex(nextIndex)
    setIsModalImageLoading(true)
  }

  const goToPreviousModalImage = () => {
    const imageItems = items.filter((item) => item.type === "image")
    const currentImageIndex = imageItems.findIndex((_, idx) => idx === modalImageIndex)
    const prevIndex = currentImageIndex === 0 ? imageItems.length - 1 : currentImageIndex - 1
    setModalImageIndex(prevIndex)
    setIsModalImageLoading(true)
  }

  // Handle image click to open modal
  const handleImageClick = (index: number) => {
    const item = items[index]
    if (item.type === "image") {
      // Find the index among image items only
      const imageItems = items.filter((item) => item.type === "image")
      const imageIndex = imageItems.findIndex((imageItem) => imageItem.id === item.id)
      setModalImageIndex(imageIndex)
      setIsModalOpen(true)
      setIsModalImageLoading(true)
      // Pause carousel when modal opens
      setIsPlaying(false)
    }
  }

  // Close modal
  const closeModal = () => {
    setIsModalOpen(false)
    setIsModalImageLoading(true)
    // Resume carousel when modal closes
    setIsPlaying(true)
  }

  // Handle keyboard navigation for modal
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (!isModalOpen) return

      switch (event.key) {
        case "Escape":
          closeModal()
          break
        case "ArrowLeft":
          event.preventDefault()
          goToPreviousModalImage()
          break
        case "ArrowRight":
          event.preventDefault()
          goToNextModalImage()
          break
      }
    }

    document.addEventListener("keydown", handleKeyDown)
    return () => document.removeEventListener("keydown", handleKeyDown)
  }, [isModalOpen])

  // Handle modal backdrop click
  const handleModalBackdropClick = (event: React.MouseEvent) => {
    if (event.target === modalRef.current) {
      closeModal()
    }
  }

  // Prevent body scroll when modal is open
  useEffect(() => {
    if (isModalOpen) {
      document.body.style.overflow = "hidden"
    } else {
      document.body.style.overflow = "unset"
    }

    return () => {
      document.body.style.overflow = "unset"
    }
  }, [isModalOpen])

  const playVideo = async (videoElement: HTMLVideoElement) => {
    try {
      // Check if video is ready to play
      if (videoElement.readyState >= 2) {
        await videoElement.play()
        setIsVideoPlaying(true)
      } else {
        // Wait for video to be ready
        const handleCanPlay = async () => {
          try {
            await videoElement.play()
            setIsVideoPlaying(true)
          } catch (error) {
            console.log("Video play failed:", error)
            setIsVideoPlaying(false)
          }
          videoElement.removeEventListener("canplay", handleCanPlay)
        }
        videoElement.addEventListener("canplay", handleCanPlay)
      }
    } catch (error) {
      console.log("Video play failed:", error)
      setIsVideoPlaying(false)
    }
  }

  const pauseVideo = (videoElement: HTMLVideoElement) => {
    try {
      videoElement.pause()
      setIsVideoPlaying(false)
    } catch (error) {
      console.log("Video pause failed:", error)
    }
  }

  const togglePlayPause = () => {
    const newIsPlaying = !isPlaying
    setIsPlaying(newIsPlaying)
    setIsUserInteracting(true)

    const currentItem = items[currentIndex]
    if (currentItem.type === "video") {
      const videoElement = videoRefs.current[currentIndex]
      if (videoElement) {
        if (newIsPlaying) {
          playVideo(videoElement)
        } else {
          pauseVideo(videoElement)
        }
      }
    }

    // Reset user interaction flag after a delay
    setTimeout(() => setIsUserInteracting(false), 1000)
  }

  // Mark media as loaded
  const handleMediaLoaded = (index: number) => {
    setLoadedMedia((prev) => ({
      ...prev,
      [index]: true,
    }))
  }

  // Handle autoplay
  useEffect(() => {
    if (isPlaying && !isUserInteracting && !isModalOpen) {
      autoPlayRef.current = setTimeout(goToNext, autoPlayInterval)
    }
    return () => {
      if (autoPlayRef.current) {
        clearTimeout(autoPlayRef.current)
      }
    }
  }, [currentIndex, isPlaying, autoPlayInterval, goToNext, isUserInteracting, isModalOpen])

  // Handle video playback when slide changes
  useEffect(() => {
    // Pause all videos first
    videoRefs.current.forEach((video, index) => {
      if (video) {
        pauseVideo(video)
        // Reset video to beginning
        video.currentTime = 0
      }
    })

    // Play current video if it's a video slide and autoplay is enabled
    const currentItem = items[currentIndex]
    if (currentItem.type === "video" && isPlaying && !isModalOpen) {
      const videoElement = videoRefs.current[currentIndex]
      if (videoElement) {
        // Small delay to ensure DOM is ready
        setTimeout(() => {
          playVideo(videoElement)
        }, 100)
      }
    }
  }, [currentIndex, isPlaying, items, isModalOpen])

  // Handle visibility change to pause videos when tab is not active
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        // Pause all videos when tab becomes hidden
        videoRefs.current.forEach((video) => {
          if (video) {
            pauseVideo(video)
          }
        })
      } else {
        // Resume current video when tab becomes visible
        const currentItem = items[currentIndex]
        if (currentItem.type === "video" && isPlaying && !isModalOpen) {
          const videoElement = videoRefs.current[currentIndex]
          if (videoElement) {
            setTimeout(() => {
              playVideo(videoElement)
            }, 100)
          }
        }
      }
    }

    document.addEventListener("visibilitychange", handleVisibilityChange)
    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange)
    }
  }, [currentIndex, isPlaying, items, isModalOpen])

  // Setup intersection observer for lazy loading
  useEffect(() => {
    const options = {
      root: null,
      rootMargin: "200px", // Start loading when within 200px of viewport
      threshold: 0.1,
    }

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const slideIndex = Number(entry.target.getAttribute("data-index"))
          if (!isNaN(slideIndex) && !loadedMedia[slideIndex]) {
            // Add to visible slides to trigger loading
            setVisibleSlides((prev) => (prev.includes(slideIndex) ? prev : [...prev, slideIndex]))
          }
        }
      })
    }, options)

    // Observe all slide elements
    slideRefs.current.forEach((slide) => {
      if (slide) {
        observer.observe(slide)
      }
    })

    return () => {
      slideRefs.current.forEach((slide) => {
        if (slide) {
          observer.unobserve(slide)
        }
      })
    }
  }, [loadedMedia])

  // Handle intersection observer for carousel visibility
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) {
            // Pause videos when carousel is not visible
            videoRefs.current.forEach((video) => {
              if (video) {
                pauseVideo(video)
              }
            })
          } else {
            // Resume current video when carousel becomes visible
            const currentItem = items[currentIndex]
            if (currentItem.type === "video" && isPlaying && !isModalOpen) {
              const videoElement = videoRefs.current[currentIndex]
              if (videoElement) {
                setTimeout(() => {
                  playVideo(videoElement)
                }, 100)
              }
            }
          }
        })
      },
      { threshold: 0.5 },
    )

    if (containerRef.current) {
      observer.observe(containerRef.current)
    }

    return () => {
      observer.disconnect()
    }
  }, [currentIndex, isPlaying, items, isModalOpen])

  // Determine if media should be loaded
  const shouldLoadMedia = (index: number) => {
    return visibleSlides.includes(index)
  }

  // Get image items for modal navigation
  const imageItems = items.filter((item) => item.type === "image")
  const currentModalImage = imageItems[modalImageIndex]

  return (
    <>
      <div ref={containerRef} className="relative w-full overflow-hidden" role="region" aria-label={t("carousel.heroCarousel")}>
        {/* Main carousel container */}
        <div className="relative h-[300px] sm:h-[400px] md:h-[500px] lg:h-[600px] w-full">
          {items.map((item, index) => (
            <div
              key={item.id}
              ref={(el) => (slideRefs.current[index] = el)}
              data-index={index}
              className={cn(
                "absolute top-0 left-0 w-full h-full transition-opacity duration-1000",
                index === currentIndex ? "opacity-100 z-10" : "opacity-0 z-0",
              )}
              aria-hidden={index !== currentIndex}
            >
              {/* Show loading state or placeholder while media loads */}
              {!loadedMedia[index] && (
                <div className="absolute inset-0 bg-gray-200 animate-pulse flex items-center justify-center" aria-hidden="true">
                  <div className="w-10 h-10 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
                </div>
              )}

              {/* Actual media content - lazy loaded */}
              {shouldLoadMedia(index) && (
                <>
                \
