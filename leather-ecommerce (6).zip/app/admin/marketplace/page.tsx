"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Clock, X, AlertCircle, Package, Eye, ChevronRight, ChevronLeft, Search } from "lucide-react"
import { useAuth } from "@/components/auth-provider"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"
import { Input } from "@/components/ui/input"

interface MarketplaceProduct {
  id: string
  title: string
  description: string
  price: number
  category: string
  condition: "new" | "like-new" | "good" | "fair"
  images: string[]
  sellerId: string
  sellerName: string
  sellerRating: number
  sellerReviews: number
  status: "pending" | "approved" | "rejected" | "sold"
  createdAt: string
  views: number
  likes: number
  tags: string[]
  location: string
  shippingOptions: string[]
  returnPolicy: string
  adminNotes?: string
}

// Mock marketplace products data for admin review
const mockPendingProducts: MarketplaceProduct[] = [
  {
    id: "p1",
    title: "El Yapımı Deri Çanta - Vintage Tarz",
    description:
      "Tamamen el yapımı, vintage tarzda deri çanta. İtalyan derisi kullanılarak üretilmiştir. İç kısmında laptop bölmesi bulunmaktadır.",
    price: 750,
    category: "çantalar",
    condition: "new",
    images: [
      "/placeholder.svg?height=400&width=400",
      "/placeholder.svg?height=400&width=400",
      "/placeholder.svg?height=400&width=400",
    ],
    sellerId: "seller1",
    sellerName: "Ahmet Yılmaz",
    sellerRating: 4.7,
    sellerReviews: 12,
    status: "pending",
    createdAt: "2024-01-20",
    views: 0,
    likes: 0,
    tags: ["el-yapımı", "vintage", "deri-çanta"],
    location: "İstanbul, Kadıköy",
    shippingOptions: ["Kargo", "Elden Teslim"],
    returnPolicy: "14 gün iade garantisi",
  },
  {
    id: "p2",
    title: "Antika Deri Cüzdan - 1960'lardan",
    description: "1960'lardan kalma antika deri cüzdan. Koleksiyonerlere özel. Çok iyi durumda.",
    price: 450,
    category: "cüzdanlar",
    condition: "good",
    images: ["/placeholder.svg?height=400&width=400", "/placeholder.svg?height=400&width=400"],
    sellerId: "seller2",
    sellerName: "Zeynep Kaya",
    sellerRating: 4.9,
    sellerReviews: 28,
    status: "pending",
    createdAt: "2024-01-19",
    views: 0,
    likes: 0,
    tags: ["antika", "koleksiyon", "vintage"],
    location: "Ankara, Çankaya",
    shippingOptions: ["Kargo"],
    returnPolicy: "İade kabul edilmez (antika ürün)",
  },
  {
    id: "p3",
    title: "El Yapımı Deri Kemer - Özel Tasarım",
    description: "Tamamen el işçiliği ile üretilmiş özel tasarım deri kemer. Gümüş toka ile birlikte.",
    price: 320,
    category: "aksesuarlar",
    condition: "new",
    images: ["/placeholder.svg?height=400&width=400"],
    sellerId: "seller3",
    sellerName: "Mehmet Demir",
    sellerRating: 4.5,
    sellerReviews: 8,
    status: "pending",
    createdAt: "2024-01-18",
    views: 0,
    likes: 0,
    tags: ["el-yapımı", "özel-tasarım", "gümüş-toka"],
    location: "İzmir, Karşıyaka",
    shippingOptions: ["Kargo", "Elden Teslim"],
    returnPolicy: "7 gün iade garantisi",
  },
]

const mockApprovedProducts: MarketplaceProduct[] = [
  {
    id: "a1",
    title: "Vintage Deri Çanta - El Yapımı",
    description: "1980'lerden kalma vintage deri çanta. Çok az kullanılmış, mükemmel durumda. İtalyan derisi.",
    price: 450,
    category: "çantalar",
    condition: "like-new",
    images: ["/placeholder.svg?height=400&width=400", "/placeholder.svg?height=400&width=400"],
    sellerId: "seller1",
    sellerName: "Ayşe Demir",
    sellerRating: 4.8,
    sellerReviews: 23,
    status: "approved",
    createdAt: "2024-01-15",
    views: 156,
    likes: 12,
    tags: ["vintage", "el-yapımı", "italyan-deri"],
    location: "İstanbul, Kadıköy",
    shippingOptions: ["Kargo", "Elden Teslim"],
    returnPolicy: "7 gün iade garantisi",
    adminNotes: "Kaliteli ürün, fotoğraflar net. Onaylandı.",
  },
  {
    id: "a2",
    title: "Deri Cüzdan Seti - Yeni",
    description: "Yeni yapılmış deri cüzdan ve kart tutucu seti. Özel tasarım, hediye kutulu.",
    price: 180,
    category: "cüzdanlar",
    condition: "new",
    images: ["/placeholder.svg?height=400&width=400"],
    sellerId: "seller2",
    sellerName: "Mehmet Özkan",
    sellerRating: 4.9,
    sellerReviews: 45,
    status: "approved",
    createdAt: "2024-01-12",
    views: 89,
    likes: 8,
    tags: ["yeni", "set", "hediye"],
    location: "Ankara, Çankaya",
    shippingOptions: ["Kargo"],
    returnPolicy: "14 gün iade garantisi",
    adminNotes: "Güzel paketlenmiş, kaliteli görünüyor. Onaylandı.",
  },
]

const mockRejectedProducts: MarketplaceProduct[] = [
  {
    id: "r1",
    title: "Deri Görünümlü Çanta",
    description: "Deri görünümlü sentetik çanta. Şık ve kullanışlı.",
    price: 120,
    category: "çantalar",
    condition: "new",
    images: ["/placeholder.svg?height=400&width=400"],
    sellerId: "seller4",
    sellerName: "Ali Yıldız",
    sellerRating: 3.5,
    sellerReviews: 4,
    status: "rejected",
    createdAt: "2024-01-14",
    views: 0,
    likes: 0,
    tags: ["sentetik", "çanta"],
    location: "Bursa, Nilüfer",
    shippingOptions: ["Kargo"],
    returnPolicy: "14 gün iade garantisi",
    adminNotes: "Ürün gerçek deri değil, sentetik. Pazaryerimizde sadece gerçek deri ürünler satılabilir.",
  },
  {
    id: "r2",
    title: "Eski Deri Cüzdan - Hasarlı",
    description: "Eski deri cüzdan, bazı yıpranmalar ve hasarlar mevcut.",
    price: 50,
    category: "cüzdanlar",
    condition: "fair",
    images: ["/placeholder.svg?height=400&width=400"],
    sellerId: "seller5",
    sellerName: "Fatma Şahin",
    sellerRating: 4.2,
    sellerReviews: 7,
    status: "rejected",
    createdAt: "2024-01-13",
    views: 0,
    likes: 0,
    tags: ["eski", "hasarlı"],
    location: "Antalya, Muratpaşa",
    shippingOptions: ["Kargo"],
    returnPolicy: "İade kabul edilmez",
    adminNotes: "Ürün çok yıpranmış ve hasarlı. Satışa uygun değil.",
  },
]

export default function AdminMarketplacePage() {
  const { user, isAuthenticated } = useAuth()
  const { toast } = useToast()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("pending")
  const [pendingProducts, setPendingProducts] = useState<MarketplaceProduct[]>(mockPendingProducts)
  const [approvedProducts, setApprovedProducts] = useState<MarketplaceProduct[]>(mockApprovedProducts)
  const [rejectedProducts, setRejectedProducts] = useState<MarketplaceProduct[]>(mockRejectedProducts)
  const [selectedProduct, setSelectedProduct] = useState<MarketplaceProduct | null>(null)
  const [adminNotes, setAdminNotes] = useState("")
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [searchQuery, setSearchQuery] = useState("")

  // Check if user is admin
  const isAdmin = isAuthenticated && user?.role === "admin"

  // Redirect if not admin
  if (!isAdmin) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <AlertCircle className="h-16 w-16 text-red-500 mx-auto mb-4" />
        <h1 className="text-2xl font-bold mb-4">Yetkisiz Erişim</h1>
        <p className="text-gray-600 mb-8">Bu sayfaya erişim yetkiniz bulunmamaktadır.</p>
        <Button onClick={() => router.push("/")}>Ana Sayfaya Dön</Button>
      </div>
    )
  }

  const handleApprove = (product: MarketplaceProduct) => {
    if (!adminNotes.trim()) {
      toast({
        title: "Not gerekli",
        description: "Lütfen onay için bir not ekleyin.",
        variant: "destructive",
      })
      return
    }

    // Update product status
    const updatedProduct = { ...product, status: "approved" as const, adminNotes }

    // Remove from pending, add to approved
    setPendingProducts((prev) => prev.filter((p) => p.id !== product.id))
    setApprovedProducts((prev) => [updatedProduct, ...prev])

    // Reset state
    setSelectedProduct(null)
    setAdminNotes("")

    toast({
      title: "Ürün onaylandı",
      description: "Ürün başarıyla onaylandı ve pazaryerinde yayınlandı.",
    })
  }

  const handleReject = (product: MarketplaceProduct) => {
    if (!adminNotes.trim()) {
      toast({
        title: "Not gerekli",
        description: "Lütfen red için bir not ekleyin.",
        variant: "destructive",
      })
      return
    }

    // Update product status
    const updatedProduct = { ...product, status: "rejected" as const, adminNotes }

    // Remove from pending, add to rejected
    setPendingProducts((prev) => prev.filter((p) => p.id !== product.id))
    setRejectedProducts((prev) => [updatedProduct, ...prev])

    // Reset state
    setSelectedProduct(null)
    setAdminNotes("")

    toast({
      title: "Ürün reddedildi",
      description: "Ürün reddedildi ve satıcıya bildirildi.",
    })
  }

  const nextImage = () => {
    if (selectedProduct) {
      setCurrentImageIndex((prev) => (prev + 1) % selectedProduct.images.length)
    }
  }

  const prevImage = () => {
    if (selectedProduct) {
      setCurrentImageIndex((prev) => (prev - 1 + selectedProduct.images.length) % selectedProduct.images.length)
    }
  }

  const getConditionLabel = (condition: string) => {
    switch (condition) {
      case "new":
        return "Yeni"
      case "like-new":
        return "Sıfır Gibi"
      case "good":
        return "İyi"
      case "fair":
        return "Orta"
      default:
        return condition
    }
  }

  const getStatusBadge = (status: MarketplaceProduct["status"]) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
            <Clock className="h-3 w-3 mr-1" />
            Onay Bekliyor
          </Badge>
        )
      case "approved":
        return (
          <Badge variant="secondary" className="bg-green-100 text-green-800">
            <CheckCircle className="h-3 w-3 mr-1" />
            Onaylandı
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="secondary" className="bg-red-100 text-red-800">
            <X className="h-3 w-3 mr-1" />
            Reddedildi
          </Badge>
        )
      case "sold":
        return (
          <Badge variant="secondary" className="bg-gray-100 text-gray-800">
            <Package className="h-3 w-3 mr-1" />
            Satıldı
          </Badge>
        )
      default:
        return null
    }
  }

  // Filter products based on search query
  const filteredPendingProducts = pendingProducts.filter(
    (product) =>
      product.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.sellerName.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const filteredApprovedProducts = approvedProducts.filter(
    (product) =>
      product.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.sellerName.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const filteredRejectedProducts = rejectedProducts.filter(
    (product) =>
      product.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.sellerName.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold">Pazaryeri Yönetimi</h1>
            <p className="text-gray-600">Satıcıların ürün listelerini yönetin ve onaylayın</p>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 bg-gray-100 px-3 py-1 rounded-lg">
              <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                {pendingProducts.length}
              </Badge>
              <span className="text-sm">Bekleyen</span>
            </div>
            <div className="flex items-center gap-2 bg-gray-100 px-3 py-1 rounded-lg">
              <Badge variant="secondary" className="bg-green-100 text-green-800">
                {approvedProducts.length}
              </Badge>
              <span className="text-sm">Onaylı</span>
            </div>
            <div className="flex items-center gap-2 bg-gray-100 px-3 py-1 rounded-lg">
              <Badge variant="secondary" className="bg-red-100 text-red-800">
                {rejectedProducts.length}
              </Badge>
              <span className="text-sm">Reddedilen</span>
            </div>
          </div>
        </div>

        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Ürün, açıklama veya satıcı ara..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Product List */}
          <div className="md:col-span-1">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="pending" className="relative">
                  Bekleyen
                  {pendingProducts.length > 0 && (
                    <Badge className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0">
                      {pendingProducts.length}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="approved">Onaylı</TabsTrigger>
                <TabsTrigger value="rejected">Reddedilen</TabsTrigger>
              </TabsList>

              <TabsContent value="pending" className="space-y-4">
                {filteredPendingProducts.length === 0 ? (
                  <div className="text-center py-8">
                    <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">Bekleyen ürün yok</h3>
                    <p className="text-gray-600">Şu anda onay bekleyen ürün bulunmuyor.</p>
                  </div>
                ) : (
                  filteredPendingProducts.map((product) => (
                    <Card
                      key={product.id}
                      className={`cursor-pointer hover:shadow-md transition-shadow ${
                        selectedProduct?.id === product.id ? "ring-2 ring-primary" : ""
                      }`}
                      onClick={() => {
                        setSelectedProduct(product)
                        setCurrentImageIndex(0)
                        setAdminNotes("")
                      }}
                    >
                      <CardContent className="p-4">
                        <div className="flex gap-3">
                          <div className="relative w-20 h-20 rounded-md overflow-hidden flex-shrink-0">
                            <Image
                              src={product.images[0] || "/placeholder.svg"}
                              alt={product.title}
                              fill
                              className="object-cover"
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="font-medium text-sm line-clamp-1">{product.title}</h3>
                            <p className="text-sm text-gray-600 line-clamp-1">{product.sellerName}</p>
                            <div className="flex items-center justify-between mt-1">
                              <span className="font-medium text-primary">₺{product.price}</span>
                              <span className="text-xs text-gray-500">
                                {new Date(product.createdAt).toLocaleDateString("tr-TR")}
                              </span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </TabsContent>

              <TabsContent value="approved" className="space-y-4">
                {filteredApprovedProducts.length === 0 ? (
                  <div className="text-center py-8">
                    <CheckCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">Onaylı ürün yok</h3>
                    <p className="text-gray-600">Şu anda onaylanmış ürün bulunmuyor.</p>
                  </div>
                ) : (
                  filteredApprovedProducts.map((product) => (
                    <Card
                      key={product.id}
                      className={`cursor-pointer hover:shadow-md transition-shadow ${
                        selectedProduct?.id === product.id ? "ring-2 ring-primary" : ""
                      }`}
                      onClick={() => {
                        setSelectedProduct(product)
                        setCurrentImageIndex(0)
                        setAdminNotes(product.adminNotes || "")
                      }}
                    >
                      <CardContent className="p-4">
                        <div className="flex gap-3">
                          <div className="relative w-20 h-20 rounded-md overflow-hidden flex-shrink-0">
                            <Image
                              src={product.images[0] || "/placeholder.svg"}
                              alt={product.title}
                              fill
                              className="object-cover"
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="font-medium text-sm line-clamp-1">{product.title}</h3>
                            <p className="text-sm text-gray-600 line-clamp-1">{product.sellerName}</p>
                            <div className="flex items-center justify-between mt-1">
                              <span className="font-medium text-primary">₺{product.price}</span>
                              <div className="flex items-center gap-1 text-xs text-gray-500">
                                <Eye className="h-3 w-3" />
                                <span>{product.views}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </TabsContent>

              <TabsContent value="rejected" className="space-y-4">
                {filteredRejectedProducts.length === 0 ? (
                  <div className="text-center py-8">
                    <X className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">Reddedilen ürün yok</h3>
                    <p className="text-gray-600">Şu anda reddedilmiş ürün bulunmuyor.</p>
                  </div>
                ) : (
                  filteredRejectedProducts.map((product) => (
                    <Card
                      key={product.id}
                      className={`cursor-pointer hover:shadow-md transition-shadow ${
                        selectedProduct?.id === product.id ? "ring-2 ring-primary" : ""
                      }`}
                      onClick={() => {
                        setSelectedProduct(product)
                        setCurrentImageIndex(0)
                        setAdminNotes(product.adminNotes || "")
                      }}
                    >
                      <CardContent className="p-4">
                        <div className="flex gap-3">
                          <div className="relative w-20 h-20 rounded-md overflow-hidden flex-shrink-0">
                            <Image
                              src={product.images[0] || "/placeholder.svg"}
                              alt={product.title}
                              fill
                              className="object-cover"
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="font-medium text-sm line-clamp-1">{product.title}</h3>
                            <p className="text-sm text-gray-600 line-clamp-1">{product.sellerName}</p>
                            <div className="flex items-center justify-between mt-1">
                              <span className="font-medium text-primary">₺{product.price}</span>
                              <span className="text-xs text-gray-500">
                                {new Date(product.createdAt).toLocaleDateString("tr-TR")}
                              </span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </TabsContent>
            </Tabs>
          </div>

          {/* Product Detail */}
          <div className="md:col-span-2">
            {selectedProduct ? (
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>{selectedProduct.title}</CardTitle>
                    {getStatusBadge(selectedProduct.status)}
                  </div>
                  <CardDescription>
                    Ürün ID: {selectedProduct.id} • Kategori: {selectedProduct.category}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Image Gallery */}
                  <div className="relative aspect-video bg-gray-100 rounded-lg overflow-hidden">
                    {selectedProduct.images.length > 0 ? (
                      <>
                        <Image
                          src={selectedProduct.images[currentImageIndex] || "/placeholder.svg"}
                          alt={selectedProduct.title}
                          fill
                          className="object-contain"
                        />
                        {selectedProduct.images.length > 1 && (
                          <>
                            <button
                              onClick={(e) => {
                                e.stopPropagation()
                                prevImage()
                              }}
                              className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-white/80 rounded-full p-2 hover:bg-white transition-colors"
                            >
                              <ChevronLeft className="h-5 w-5" />
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation()
                                nextImage()
                              }}
                              className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-white/80 rounded-full p-2 hover:bg-white transition-colors"
                            >
                              <ChevronRight className="h-5 w-5" />
                            </button>
                            <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 flex gap-1">
                              {selectedProduct.images.map((_, index) => (
                                <div
                                  key={index}
                                  className={`h-2 w-2 rounded-full ${
                                    index === currentImageIndex ? "bg-primary" : "bg-gray-300"
                                  }`}
                                />
                              ))}
                            </div>
                          </>
                        )}
                      </>
                    ) : (
                      <div className="flex items-center justify-center h-full">
                        <p className="text-gray-500">Resim yok</p>
                      </div>
                    )}
                  \
