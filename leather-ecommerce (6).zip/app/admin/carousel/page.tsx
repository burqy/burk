"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { Trash2, Plus, MoveUp, MoveDown, ImageIcon, Video } from "lucide-react"
import Image from "next/image"

interface CarouselItem {
  id: number
  type: "image" | "video"
  src: string
  thumbnailSrc?: string
  alt?: string
  title: string
  description: string
  buttonText: string
  buttonLink: string
}

export default function CarouselAdminPage() {
  const { toast } = useToast()
  const [items, setItems] = useState<CarouselItem[]>([
    {
      id: 1,
      type: "image",
      src: "/placeholder.svg?height=600&width=1200",
      thumbnailSrc: "/placeholder.svg?height=100&width=200",
      alt: "Premium Deri Koleksiyonu",
      title: "Premium Deri Koleksiyonu",
      description: "El yapımı deri ürünlerimizle tarzınızı yansıtın",
      buttonText: "Koleksiyonu Keşfet",
      buttonLink: "/products",
    },
    {
      id: 2,
      type: "video",
      src: "https://cdn.plyr.io/static/demo/View_From_A_Blue_Moon_Trailer-720p.mp4",
      thumbnailSrc: "/placeholder.svg?height=100&width=200",
      title: "Deri İşçiliği Sanatı",
      description: "Usta zanaatkarlarımızın elinden çıkan eşsiz ürünler",
      buttonText: "Nasıl Yapıyoruz?",
      buttonLink: "/about",
    },
  ])

  const addNewItem = () => {
    const newId = items.length > 0 ? Math.max(...items.map((item) => item.id)) + 1 : 1
    const newItem: CarouselItem = {
      id: newId,
      type: "image",
      src: "/placeholder.svg?height=600&width=1200",
      thumbnailSrc: "/placeholder.svg?height=100&width=200",
      alt: "",
      title: "Yeni Slayt",
      description: "Slayt açıklaması",
      buttonText: "Daha Fazla",
      buttonLink: "/",
    }
    setItems([...items, newItem])
  }

  const updateItem = (id: number, field: keyof CarouselItem, value: string) => {
    setItems(
      items.map((item) => {
        if (item.id === id) {
          return { ...item, [field]: value }
        }
        return item
      }),
    )
  }

  const removeItem = (id: number) => {
    setItems(items.filter((item) => item.id !== id))
    toast({
      title: "Slayt silindi",
      description: "Slayt başarıyla kaldırıldı.",
    })
  }

  const moveItem = (id: number, direction: "up" | "down") => {
    const index = items.findIndex((item) => item.id === id)
    if ((direction === "up" && index === 0) || (direction === "down" && index === items.length - 1)) {
      return
    }

    const newItems = [...items]
    const newIndex = direction === "up" ? index - 1 : index + 1
    const temp = newItems[index]
    newItems[index] = newItems[newIndex]
    newItems[newIndex] = temp
    setItems(newItems)
  }

  const saveChanges = () => {
    // Burada API'ye kaydetme işlemi yapılacak
    toast({
      title: "Değişiklikler kaydedildi",
      description: "Carousel ayarları başarıyla güncellendi.",
    })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Ana Sayfa Carousel Yönetimi</h1>
        <Button onClick={saveChanges}>Değişiklikleri Kaydet</Button>
      </div>

      <div className="space-y-6">
        {items.map((item, index) => (
          <Card key={item.id} className="border-2">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div>
                <CardTitle className="text-xl">
                  Slayt {index + 1}: {item.title}
                </CardTitle>
                <CardDescription>{item.type === "image" ? "Görsel" : "Video"} Slayt</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon" onClick={() => moveItem(item.id, "up")} disabled={index === 0}>
                  <MoveUp className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => moveItem(item.id, "down")}
                  disabled={index === items.length - 1}
                >
                  <MoveDown className="h-4 w-4" />
                </Button>
                <Button variant="destructive" size="icon" onClick={() => removeItem(item.id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor={`type-${item.id}`}>Slayt Tipi</Label>
                    <Select
                      value={item.type}
                      onValueChange={(value) => updateItem(item.id, "type", value as "image" | "video")}
                    >
                      <SelectTrigger id={`type-${item.id}`}>
                        <SelectValue placeholder="Slayt tipini seçin" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="image">Görsel</SelectItem>
                        <SelectItem value="video">Video</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`src-${item.id}`}>{item.type === "image" ? "Görsel URL" : "Video URL"}</Label>
                    <Input
                      id={`src-${item.id}`}
                      value={item.src}
                      onChange={(e) => updateItem(item.id, "src", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`thumbnailSrc-${item.id}`}>Küçük Resim URL (Önizleme için)</Label>
                    <Input
                      id={`thumbnailSrc-${item.id}`}
                      value={item.thumbnailSrc || ""}
                      onChange={(e) => updateItem(item.id, "thumbnailSrc", e.target.value)}
                    />
                    <p className="text-xs text-gray-500">
                      Düşük çözünürlüklü bir önizleme resmi ekleyin. Bu, tam boyutlu medya yüklenirken gösterilecektir.
                    </p>
                  </div>

                  {item.type === "image" && (
                    <div className="space-y-2">
                      <Label htmlFor={`alt-${item.id}`}>Alt Metin</Label>
                      <Input
                        id={`alt-${item.id}`}
                        value={item.alt || ""}
                        onChange={(e) => updateItem(item.id, "alt", e.target.value)}
                      />
                    </div>
                  )}

                  <div className="space-y-2">
                    <Label htmlFor={`title-${item.id}`}>Başlık</Label>
                    <Input
                      id={`title-${item.id}`}
                      value={item.title}
                      onChange={(e) => updateItem(item.id, "title", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`description-${item.id}`}>Açıklama</Label>
                    <Textarea
                      id={`description-${item.id}`}
                      value={item.description}
                      onChange={(e) => updateItem(item.id, "description", e.target.value)}
                      rows={3}
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor={`buttonText-${item.id}`}>Buton Metni</Label>
                    <Input
                      id={`buttonText-${item.id}`}
                      value={item.buttonText}
                      onChange={(e) => updateItem(item.id, "buttonText", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`buttonLink-${item.id}`}>Buton Bağlantısı</Label>
                    <Input
                      id={`buttonLink-${item.id}`}
                      value={item.buttonLink}
                      onChange={(e) => updateItem(item.id, "buttonLink", e.target.value)}
                    />
                  </div>

                  <div className="border rounded-lg p-4 mt-4">
                    <h4 className="font-medium mb-2">Önizleme</h4>
                    <div className="relative aspect-video bg-gray-100 rounded-lg overflow-hidden">
                      {item.type === "image" ? (
                        item.src ? (
                          <Image
                            src={item.src || "/placeholder.svg"}
                            alt={item.alt || item.title}
                            fill
                            className="object-cover"
                          />
                        ) : (
                          <div className="flex items-center justify-center h-full">
                            <ImageIcon className="h-12 w-12 text-gray-400" />
                          </div>
                        )
                      ) : item.src ? (
                        <video className="w-full h-full object-cover" muted>
                          <source src={item.src} type="video/mp4" />
                          Your browser does not support the video tag.
                        </video>
                      ) : (
                        <div className="flex items-center justify-center h-full">
                          <Video className="h-12 w-12 text-gray-400" />
                        </div>
                      )}
                      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-4">
                        <h3 className="text-white font-bold truncate">{item.title}</h3>
                        <p className="text-white/80 text-sm line-clamp-2">{item.description}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        <Button onClick={addNewItem} className="w-full" variant="outline">
          <Plus className="mr-2 h-4 w-4" />
          Yeni Slayt Ekle
        </Button>
      </div>
    </div>
  )
}
