"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  User,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Award,
  ShoppingBag,
  Star,
  Gift,
  Settings,
  Bell,
  Download,
  FileText,
  Eye,
} from "lucide-react"
import { useAuth } from "@/components/auth-provider"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"

const membershipTiers = {
  bronze: { name: "Bronz", color: "bg-amber-600", nextTier: "silver", threshold: 500 },
  silver: { name: "Gümüş", color: "bg-gray-400", nextTier: "gold", threshold: 2000 },
  gold: { name: "Altın", color: "bg-yellow-500", nextTier: "platinum", threshold: 5000 },
  platinum: { name: "Platin", color: "bg-purple-600", nextTier: null, threshold: null },
}

const membershipBenefits = {
  bronze: ["Ücretsiz kargo (500₺ üzeri)", "Doğum günü indirimi %5"],
  silver: ["Ücretsiz kargo (tüm siparişler)", "Doğum günü indirimi %10", "Erken erişim kampanyalar"],
  gold: [
    "Ücretsiz kargo + hızlı teslimat",
    "Doğum günü indirimi %15",
    "Özel müşteri hizmetleri",
    "Ücretsiz hediye paketi",
  ],
  platinum: [
    "Premium ücretsiz kargo",
    "Doğum günü indirimi %20",
    "Kişisel alışveriş danışmanı",
    "Özel etkinlik davetleri",
    "Sınırsız ücretsiz hediye paketi",
  ],
}

export default function ProfilePage() {
  const { user, isAuthenticated, updateProfile } = useAuth()
  const { toast } = useToast()
  const router = useRouter()
  const [isEditing, setIsEditing] = useState(false)
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    birthDate: "",
    gender: "",
    city: "",
    district: "",
    address: "",
  })

  useEffect(() => {
    if (!isAuthenticated) {
      router.push("/auth/login")
      return
    }

    if (user) {
      setFormData({
        firstName: user.firstName || "",
        lastName: user.lastName || "",
        email: user.email || "",
        phone: user.phone || "",
        birthDate: user.birthDate || "",
        gender: user.gender || "",
        city: user.city || "",
        district: user.district || "",
        address: user.address || "",
      })
    }
  }, [user, isAuthenticated, router])

  useEffect(() => {
    // Handle URL tab parameter
    const urlParams = new URLSearchParams(window.location.search)
    const tab = urlParams.get("tab")
    if (tab && ["profile", "membership", "orders", "digital", "loyalty", "settings"].includes(tab)) {
      // You would set the active tab here - for now we'll just scroll to the section
      const tabElement = document.querySelector(`[value="${tab}"]`)
      if (tabElement) {
        ;(tabElement as HTMLElement).click()
      }
    }
  }, [])

  if (!isAuthenticated || !user) {
    return null
  }

  const currentTier = membershipTiers[user.membershipTier]
  const progressToNext = currentTier.nextTier ? (user.totalSpent / currentTier.threshold) * 100 : 100

  const handleSave = async () => {
    const success = await updateProfile(formData)
    if (success) {
      toast({
        title: "Profil güncellendi",
        description: "Bilgileriniz başarıyla kaydedildi.",
      })
      setIsEditing(false)
    } else {
      toast({
        title: "Hata",
        description: "Profil güncellenirken bir hata oluştu.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center text-white text-2xl font-bold">
            {user.firstName.charAt(0)}
            {user.lastName.charAt(0)}
          </div>
          <div>
            <h1 className="text-3xl font-bold">
              {user.firstName} {user.lastName}
            </h1>
            <div className="flex items-center gap-2">
              <Badge className={`${currentTier.color} text-white`}>{currentTier.name} Üye</Badge>
              <span className="text-gray-600">{user.orderCount} sipariş</span>
            </div>
          </div>
        </div>

        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="profile">Profil</TabsTrigger>
            <TabsTrigger value="membership">Üyelik</TabsTrigger>
            <TabsTrigger value="orders">Siparişler</TabsTrigger>
            <TabsTrigger value="digital">Dijital Ürünler</TabsTrigger>
            <TabsTrigger value="loyalty">Puan</TabsTrigger>
            <TabsTrigger value="settings">Ayarlar</TabsTrigger>
          </TabsList>

          <TabsContent value="profile">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Kişisel Bilgiler</CardTitle>
                    <CardDescription>Hesap bilgilerinizi görüntüleyin ve düzenleyin</CardDescription>
                  </div>
                  <Button
                    variant={isEditing ? "default" : "outline"}
                    onClick={() => (isEditing ? handleSave() : setIsEditing(true))}
                  >
                    {isEditing ? "Kaydet" : "Düzenle"}
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">Ad</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="firstName"
                        value={formData.firstName}
                        onChange={(e) => setFormData((prev) => ({ ...prev, firstName: e.target.value }))}
                        className="pl-10"
                        disabled={!isEditing}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Soyad</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="lastName"
                        value={formData.lastName}
                        onChange={(e) => setFormData((prev) => ({ ...prev, lastName: e.target.value }))}
                        className="pl-10"
                        disabled={!isEditing}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">E-posta</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="email"
                      value={formData.email}
                      onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                      className="pl-10"
                      disabled={!isEditing}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Telefon</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData((prev) => ({ ...prev, phone: e.target.value }))}
                      className="pl-10"
                      disabled={!isEditing}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="birthDate">Doğum Tarihi</Label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="birthDate"
                        type="date"
                        value={formData.birthDate}
                        onChange={(e) => setFormData((prev) => ({ ...prev, birthDate: e.target.value }))}
                        className="pl-10"
                        disabled={!isEditing}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="gender">Cinsiyet</Label>
                    <Select
                      value={formData.gender}
                      onValueChange={(value) => setFormData((prev) => ({ ...prev, gender: value }))}
                      disabled={!isEditing}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Seçiniz" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Erkek</SelectItem>
                        <SelectItem value="female">Kadın</SelectItem>
                        <SelectItem value="other">Diğer</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="city">Şehir</Label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input
                        id="city"
                        value={formData.city}
                        onChange={(e) => setFormData((prev) => ({ ...prev, city: e.target.value }))}
                        className="pl-10"
                        disabled={!isEditing}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="district">İlçe</Label>
                    <Input
                      id="district"
                      value={formData.district}
                      onChange={(e) => setFormData((prev) => ({ ...prev, district: e.target.value }))}
                      disabled={!isEditing}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Adres</Label>
                  <Input
                    id="address"
                    value={formData.address}
                    onChange={(e) => setFormData((prev) => ({ ...prev, address: e.target.value }))}
                    disabled={!isEditing}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="membership">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Award className="h-5 w-5" />
                    Üyelik Durumu
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-lg font-semibold">{currentTier.name} Üye</h3>
                        <p className="text-gray-600">Toplam harcama: ₺{user.totalSpent}</p>
                      </div>
                      <Badge className={`${currentTier.color} text-white text-lg px-4 py-2`}>{currentTier.name}</Badge>
                    </div>

                    {currentTier.nextTier && (
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>{membershipTiers[currentTier.nextTier].name} üyelik için</span>
                          <span>₺{currentTier.threshold - user.totalSpent} kaldı</span>
                        </div>
                        <Progress value={progressToNext} className="h-2" />
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Üyelik Avantajları</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {membershipBenefits[user.membershipTier].map((benefit, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <Star className="h-4 w-4 text-yellow-500" />
                        <span>{benefit}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="orders">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ShoppingBag className="h-5 w-5" />
                  Sipariş Geçmişi
                </CardTitle>
              </CardHeader>
              <CardContent>
                {user.orderCount > 0 ? (
                  <div className="space-y-6">
                    {/* Sample orders - in real app this would come from API */}
                    <div className="border rounded-lg p-4">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="font-semibold">Sipariş #12345</h3>
                          <p className="text-sm text-gray-600">15 Aralık 2024</p>
                        </div>
                        <Badge variant="default">Tamamlandı</Badge>
                      </div>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <Download className="h-5 w-5 text-green-600" />
                            <div>
                              <h4 className="font-medium">Deri Bakım Rehberi (PDF)</h4>
                              <p className="text-sm text-gray-600">Dijital Ürün • 52 sayfa</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">₺9.99</span>
                            <Button size="sm" variant="outline">
                              <Download className="h-4 w-4 mr-1" />
                              İndir
                            </Button>
                          </div>
                        </div>
                        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <ShoppingBag className="h-5 w-5 text-blue-600" />
                            <div>
                              <h4 className="font-medium">Premium Deri Cüzdan</h4>
                              <p className="text-sm text-gray-600">Fiziksel Ürün • Kahverengi</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">₺89.99</span>
                            <Badge variant="secondary">Teslim Edildi</Badge>
                          </div>
                        </div>
                      </div>
                      <div className="mt-4 pt-4 border-t flex justify-between">
                        <span className="font-medium">Toplam:</span>
                        <span className="font-bold">₺99.98</span>
                      </div>
                    </div>

                    <div className="border rounded-lg p-4">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="font-semibold">Sipariş #12344</h3>
                          <p className="text-sm text-gray-600">10 Aralık 2024</p>
                        </div>
                        <Badge variant="default">Tamamlandı</Badge>
                      </div>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <Download className="h-5 w-5 text-green-600" />
                            <div>
                              <h4 className="font-medium">Deri İşçiliği Eğitimi (PDF)</h4>
                              <p className="text-sm text-gray-600">Dijital Ürün • 78 sayfa</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">₺19.99</span>
                            <Button size="sm" variant="outline">
                              <Download className="h-4 w-4 mr-1" />
                              İndir
                            </Button>
                          </div>
                        </div>
                        <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <Download className="h-5 w-5 text-green-600" />
                            <div>
                              <h4 className="font-medium">İleri Deri Teknikleri (PDF)</h4>
                              <p className="text-sm text-gray-600">Dijital Ürün • 124 sayfa</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium">₺29.99</span>
                            <Button size="sm" variant="outline">
                              <Download className="h-4 w-4 mr-1" />
                              İndir
                            </Button>
                          </div>
                        </div>
                      </div>
                      <div className="mt-4 pt-4 border-t flex justify-between">
                        <span className="font-medium">Toplam:</span>
                        <span className="font-bold">₺49.98</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <ShoppingBag className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">Henüz sipariş vermediniz</p>
                    <Button className="mt-4" asChild>
                      <a href="/products">Alışverişe Başla</a>
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="digital">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Download className="h-5 w-5" />
                  Dijital Ürünlerim
                </CardTitle>
                <CardDescription>Satın aldığınız dijital ürünleri buradan indirebilirsiniz</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Digital Product 1 */}
                  <div className="border rounded-lg p-4 bg-green-50">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 bg-green-100 rounded-lg flex items-center justify-center">
                          <FileText className="h-8 w-8 text-green-600" />
                        </div>
                        <div>
                          <h3 className="font-semibold">Deri Bakım Rehberi (PDF)</h3>
                          <p className="text-sm text-gray-600">Satın alma: 15 Aralık 2024</p>
                          <p className="text-sm text-gray-600">52 sayfa • 15 MB</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="secondary" className="text-xs">
                              Aktif
                            </Badge>
                            <span className="text-xs text-gray-500">25 gün kaldı</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-col gap-2">
                        <Button size="sm">
                          <Download className="h-4 w-4 mr-1" />
                          İndir
                        </Button>
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4 mr-1" />
                          Önizle
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Digital Product 2 */}
                  <div className="border rounded-lg p-4 bg-green-50">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 bg-green-100 rounded-lg flex items-center justify-center">
                          <FileText className="h-8 w-8 text-green-600" />
                        </div>
                        <div>
                          <h3 className="font-semibold">Deri İşçiliği Eğitimi (PDF)</h3>
                          <p className="text-sm text-gray-600">Satın alma: 10 Aralık 2024</p>
                          <p className="text-sm text-gray-600">78 sayfa • 25 MB</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="secondary" className="text-xs">
                              Aktif
                            </Badge>
                            <span className="text-xs text-gray-500">20 gün kaldı</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-col gap-2">
                        <Button size="sm">
                          <Download className="h-4 w-4 mr-1" />
                          İndir
                        </Button>
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4 mr-1" />
                          Önizle
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Digital Product 3 */}
                  <div className="border rounded-lg p-4 bg-green-50">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 bg-green-100 rounded-lg flex items-center justify-center">
                          <FileText className="h-8 w-8 text-green-600" />
                        </div>
                        <div>
                          <h3 className="font-semibold">İleri Deri Teknikleri (PDF)</h3>
                          <p className="text-sm text-gray-600">Satın alma: 10 Aralık 2024</p>
                          <p className="text-sm text-gray-600">124 sayfa • 40 MB</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="secondary" className="text-xs">
                              Aktif
                            </Badge>
                            <span className="text-xs text-gray-500">20 gün kaldı</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-col gap-2">
                        <Button size="sm">
                          <Download className="h-4 w-4 mr-1" />
                          İndir
                        </Button>
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4 mr-1" />
                          Önizle
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Expired Product Example */}
                  <div className="border rounded-lg p-4 bg-gray-50 opacity-75">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 bg-gray-200 rounded-lg flex items-center justify-center">
                          <FileText className="h-8 w-8 text-gray-400" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-600">Deri İşi Başlangıç Kiti (PDF)</h3>
                          <p className="text-sm text-gray-500">Satın alma: 1 Kasım 2024</p>
                          <p className="text-sm text-gray-500">96 sayfa • 30 MB</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="destructive" className="text-xs">
                              Süresi Doldu
                            </Badge>
                            <span className="text-xs text-gray-500">30 gün geçti</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-col gap-2">
                        <Button size="sm" variant="outline" disabled>
                          <Download className="h-4 w-4 mr-1" />
                          Süresi Doldu
                        </Button>
                        <Button size="sm" variant="outline">
                          Yeniden Satın Al
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Download Instructions */}
                <div className="mt-8 p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-2">İndirme Talimatları</h4>
                  <ul className="text-sm text-blue-800 space-y-1">
                    <li>• İndirme bağlantıları satın alma tarihinden itibaren 30 gün geçerlidir</li>
                    <li>• PDF dosyaları şifre korumalıdır, şifre e-postanızda belirtilmiştir</li>
                    <li>• Dosyaları maksimum 5 cihazda açabilirsiniz</li>
                    <li>• Sorun yaşarsanız müşteri hizmetlerimizle iletişime geçin</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="loyalty">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Gift className="h-5 w-5" />
                  Sadakat Puanları
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <div className="text-4xl font-bold text-primary">{user.loyaltyPoints}</div>
                    <p className="text-gray-600">Mevcut Puanınız</p>
                  </div>

                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2">Puan Kazanma</h4>
                    <ul className="text-sm space-y-1">
                      <li>• Her 1₺ harcama = 1 puan</li>
                      <li>• Ürün yorumu = 10 puan</li>
                      <li>• Doğum günü bonusu = 50 puan</li>
                    </ul>
                  </div>

                  <div className="bg-green-50 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2">Puan Kullanma</h4>
                    <ul className="text-sm space-y-1">
                      <li>• 100 puan = 5₺ indirim</li>
                      <li>• 500 puan = 30₺ indirim</li>
                      <li>• 1000 puan = 70₺ indirim</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Bell className="h-5 w-5" />
                    Bildirim Ayarları
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">E-posta Bildirimleri</h4>
                        <p className="text-sm text-gray-600">Kampanya ve fırsatlar hakkında bilgi alın</p>
                      </div>
                      <input type="checkbox" defaultChecked={user.acceptsMarketing} />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">Sipariş Bildirimleri</h4>
                        <p className="text-sm text-gray-600">Sipariş durumu güncellemeleri</p>
                      </div>
                      <input type="checkbox" defaultChecked />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Hesap Ayarları
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <Button variant="outline" className="w-full">
                      Şifre Değiştir
                    </Button>
                    <Button variant="outline" className="w-full">
                      E-posta Doğrula
                    </Button>
                    <Button variant="destructive" className="w-full">
                      Hesabı Sil
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
