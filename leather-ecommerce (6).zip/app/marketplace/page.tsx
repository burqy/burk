"use client"

import type React from "react"

import { useState, useRef, useCallback, useEffect } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Upload,
  X,
  ImageIcon,
  User,
  Heart,
  MessageCircle,
  Share2,
  ShoppingCart,
  AlertCircle,
  CheckCircle,
  Clock,
  Star,
  Eye,
  Package,
  TrendingUp,
} from "lucide-react"
import { useAuth } from "@/components/auth-provider"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"

interface MarketplaceProduct {
  id: string
  title: string
  description: string
  price: number
  category: string
  condition: "new" | "like-new" | "good" | "fair"
  images: string[]
  sellerId: string
  sellerName: string
  sellerRating: number
  sellerReviews: number
  status: "pending" | "approved" | "rejected" | "sold"
  createdAt: string
  views: number
  likes: number
  isLiked: boolean
  tags: string[]
  location: string
  shippingOptions: string[]
  returnPolicy: string
}

// Mock marketplace products data
const mockMarketplaceProducts: MarketplaceProduct[] = [
  {
    id: "1",
    title: "Vintage Deri Çanta - El Yapımı",
    description: "1980'lerden kalma vintage deri çanta. Çok az kullanılmış, mükemmel durumda. İtalyan derisi.",
    price: 450,
    category: "çantalar",
    condition: "like-new",
    images: ["/placeholder.svg?height=400&width=400", "/placeholder.svg?height=400&width=400"],
    sellerId: "seller1",
    sellerName: "Ayşe Demir",
    sellerRating: 4.8,
    sellerReviews: 23,
    status: "approved",
    createdAt: "2024-01-15",
    views: 156,
    likes: 12,
    isLiked: false,
    tags: ["vintage", "el-yapımı", "italyan-deri"],
    location: "İstanbul, Kadıköy",
    shippingOptions: ["Kargo", "Elden Teslim"],
    returnPolicy: "7 gün iade garantisi",
  },
  {
    id: "2",
    title: "Deri Cüzdan Seti - Yeni",
    description: "Yeni yapılmış deri cüzdan ve kart tutucu seti. Özel tasarım, hediye kutulu.",
    price: 180,
    category: "cüzdanlar",
    condition: "new",
    images: ["/placeholder.svg?height=400&width=400"],
    sellerId: "seller2",
    sellerName: "Mehmet Özkan",
    sellerRating: 4.9,
    sellerReviews: 45,
    status: "approved",
    createdAt: "2024-01-12",
    views: 89,
    likes: 8,
    isLiked: true,
    tags: ["yeni", "set", "hediye"],
    location: "Ankara, Çankaya",
    shippingOptions: ["Kargo"],
    returnPolicy: "14 gün iade garantisi",
  },
  {
    id: "3",
    title: "Antika Deri Kemer",
    description: "1950'lerden kalma antika deri kemer. Koleksiyoncular için ideal.",
    price: 320,
    category: "aksesuarlar",
    condition: "good",
    images: ["/placeholder.svg?height=400&width=400", "/placeholder.svg?height=400&width=400"],
    sellerId: "seller3",
    sellerName: "Zeynep Kaya",
    sellerRating: 4.7,
    sellerReviews: 18,
    status: "approved",
    createdAt: "2024-01-10",
    views: 234,
    likes: 19,
    isLiked: false,
    tags: ["antika", "koleksiyon", "vintage"],
    location: "İzmir, Konak",
    shippingOptions: ["Kargo", "Elden Teslim"],
    returnPolicy: "İade yok (antika ürün)",
  },
]

const categories = [
  { value: "çantalar", label: "Çantalar" },
  { value: "cüzdanlar", label: "Cüzdanlar" },
  { value: "kart-tutucular", label: "Kart Tutucular" },
  { value: "aksesuarlar", label: "Aksesuarlar" },
  { value: "kemerler", label: "Kemerler" },
  { value: "ayakkabılar", label: "Ayakkabılar" },
  { value: "diğer", label: "Diğer" },
]

const conditions = [
  { value: "new", label: "Yeni", description: "Hiç kullanılmamış" },
  { value: "like-new", label: "Sıfır Gibi", description: "Çok az kullanılmış" },
  { value: "good", label: "İyi", description: "Normal kullanım izleri" },
  { value: "fair", label: "Orta", description: "Belirgin kullanım izleri" },
]

export default function MarketplacePage() {
  const { user, isAuthenticated } = useAuth()
  const { toast } = useToast()
  const router = useRouter()
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [selectedFiles, setSelectedFiles] = useState<File[]>([])
  const [productForm, setProductForm] = useState({
    title: "",
    description: "",
    price: "",
    category: "",
    condition: "",
    tags: "",
    location: "",
    shippingOptions: [] as string[],
    returnPolicy: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [marketplaceProducts, setMarketplaceProducts] = useState<MarketplaceProduct[]>(mockMarketplaceProducts)
  const [activeTab, setActiveTab] = useState("marketplace")
  const [userProducts, setUserProducts] = useState<MarketplaceProduct[]>([])
  const [filterCategory, setFilterCategory] = useState("all")
  const [filterCondition, setFilterCondition] = useState("all")
  const [sortBy, setSortBy] = useState("newest")
  const [isAuthChecked, setIsAuthChecked] = useState(false)

  // Move all useEffect hooks here, before any conditional returns
  useEffect(() => {
    // Check authentication
    if (!isAuthenticated) {
      router.push("/auth/login")
    }
    setIsAuthChecked(true)
  }, [isAuthenticated, router])

  useEffect(() => {
    // Filter user products
    if (user?.id) {
      const userProductsList = mockMarketplaceProducts.filter((product) => product.sellerId === user?.id)
      setUserProducts(userProductsList)
    }
  }, [user?.id])

  const handleFileSelect = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      const files = Array.from(event.target.files || [])
      const validFiles = files.filter((file) => {
        const isValidType = file.type.startsWith("image/")
        const isValidSize = file.size <= 10 * 1024 * 1024 // 10MB limit

        if (!isValidType) {
          toast({
            title: "Geçersiz dosya türü",
            description: "Sadece resim dosyaları yükleyebilirsiniz.",
            variant: "destructive",
          })
          return false
        }

        if (!isValidSize) {
          toast({
            title: "Dosya çok büyük",
            description: "Dosya boyutu 10MB'dan küçük olmalıdır.",
            variant: "destructive",
          })
          return false
        }

        return true
      })

      setSelectedFiles((prev) => [...prev, ...validFiles].slice(0, 8)) // Max 8 files
    },
    [toast],
  )

  const handleDrop = useCallback(
    (event: React.DragEvent) => {
      event.preventDefault()
      const files = Array.from(event.dataTransfer.files)
      const fakeEvent = {
        target: { files },
      } as React.ChangeEvent<HTMLInputElement>
      handleFileSelect(fakeEvent)
    },
    [handleFileSelect],
  )

  const handleDragOver = useCallback((event: React.DragEvent) => {
    event.preventDefault()
  }, [])

  const removeFile = useCallback((index: number) => {
    setSelectedFiles((prev) => prev.filter((_, i) => i !== index))
  }, [])

  const handleShippingOptionChange = useCallback((option: string, checked: boolean) => {
    setProductForm((prev) => ({
      ...prev,
      shippingOptions: checked
        ? [...prev.shippingOptions, option]
        : prev.shippingOptions.filter((opt) => opt !== option),
    }))
  }, [])

  const handleSubmitProduct = useCallback(async () => {
    if (selectedFiles.length === 0) {
      toast({
        title: "Resim gerekli",
        description: "En az bir ürün resmi yüklemelisiniz.",
        variant: "destructive",
      })
      return
    }

    if (!productForm.title.trim() || !productForm.description.trim() || !productForm.price) {
      toast({
        title: "Eksik bilgiler",
        description: "Lütfen tüm zorunlu alanları doldurun.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Simulate submission process
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Create new product entry
      const newProduct: MarketplaceProduct = {
        id: Date.now().toString(),
        title: productForm.title,
        description: productForm.description,
        price: Number.parseFloat(productForm.price),
        category: productForm.category,
        condition: productForm.condition as MarketplaceProduct["condition"],
        images: selectedFiles.map((file) => URL.createObjectURL(file)),
        sellerId: user?.id || "",
        sellerName: `${user?.firstName} ${user?.lastName}`,
        sellerRating: 5.0,
        sellerReviews: 0,
        status: "pending",
        createdAt: new Date().toISOString().split("T")[0],
        views: 0,
        likes: 0,
        isLiked: false,
        tags: productForm.tags
          .split(",")
          .map((tag) => tag.trim())
          .filter(Boolean),
        location: productForm.location,
        shippingOptions: productForm.shippingOptions,
        returnPolicy: productForm.returnPolicy,
      }

      setUserProducts((prev) => [newProduct, ...prev])
      setSelectedFiles([])
      setProductForm({
        title: "",
        description: "",
        price: "",
        category: "",
        condition: "",
        tags: "",
        location: "",
        shippingOptions: [],
        returnPolicy: "",
      })
      setActiveTab("my-products")

      toast({
        title: "Ürün başarıyla gönderildi!",
        description: "Ürününüz admin onayı için gönderildi. Onaylandıktan sonra satışa çıkacak.",
      })
    } catch (error) {
      toast({
        title: "Gönderim hatası",
        description: "Ürün gönderilirken bir hata oluştu.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }, [productForm, selectedFiles, toast, user])

  const toggleLike = useCallback((productId: string) => {
    setMarketplaceProducts((prev) =>
      prev.map((product) =>
        product.id === productId
          ? {
              ...product,
              isLiked: !product.isLiked,
              likes: product.isLiked ? product.likes - 1 : product.likes + 1,
            }
          : product,
      ),
    )
  }, [])

  const getStatusBadge = useCallback((status: MarketplaceProduct["status"]) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
            <Clock className="h-3 w-3 mr-1" />
            Onay Bekliyor
          </Badge>
        )
      case "approved":
        return (
          <Badge variant="secondary" className="bg-green-100 text-green-800">
            <CheckCircle className="h-3 w-3 mr-1" />
            Onaylandı
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="secondary" className="bg-red-100 text-red-800">
            <X className="h-3 w-3 mr-1" />
            Reddedildi
          </Badge>
        )
      case "sold":
        return (
          <Badge variant="secondary" className="bg-gray-100 text-gray-800">
            <Package className="h-3 w-3 mr-1" />
            Satıldı
          </Badge>
        )
      default:
        return null
    }
  }, [])

  const getConditionBadge = useCallback((condition: MarketplaceProduct["condition"]) => {
    const conditionInfo = conditions.find((c) => c.value === condition)
    return (
      <Badge variant="outline" className="text-xs">
        {conditionInfo?.label}
      </Badge>
    )
  }, [])

  // Now we can safely do an early return after all hooks are defined
  if (!isAuthChecked || !isAuthenticated) {
    return null
  }

  // Filter and sort products
  const filteredProducts = marketplaceProducts
    .filter((product) => product.status === "approved")
    .filter((product) => filterCategory === "all" || product.category === filterCategory)
    .filter((product) => filterCondition === "all" || product.condition === filterCondition)
    .sort((a, b) => {
      switch (sortBy) {
        case "price-low":
          return a.price - b.price
        case "price-high":
          return b.price - a.price
        case "popular":
          return b.views - a.views
        case "rating":
          return b.sellerRating - a.sellerRating
        default: // newest
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      }
    })

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-4">Deri Ürünleri Pazaryeri</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Kendi deri ürünlerinizi satın veya diğer üyelerimizin eşsiz ürünlerini keşfedin
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="marketplace">Pazaryeri</TabsTrigger>
            <TabsTrigger value="sell">Ürün Sat</TabsTrigger>
            <TabsTrigger value="my-products">Ürünlerim</TabsTrigger>
          </TabsList>

          <TabsContent value="marketplace" className="space-y-6">
            {/* Filters */}
            <Card>
              <CardContent className="p-4">
                <div className="flex flex-wrap gap-4 items-center">
                  <div className="flex items-center gap-2">
                    <Label htmlFor="category-filter">Kategori:</Label>
                    <Select value={filterCategory} onValueChange={setFilterCategory}>
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Tümü</SelectItem>
                        {categories.map((category) => (
                          <SelectItem key={category.value} value={category.value}>
                            {category.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center gap-2">
                    <Label htmlFor="condition-filter">Durum:</Label>
                    <Select value={filterCondition} onValueChange={setFilterCondition}>
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Tümü</SelectItem>
                        {conditions.map((condition) => (
                          <SelectItem key={condition.value} value={condition.value}>
                            {condition.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center gap-2">
                    <Label htmlFor="sort-filter">Sırala:</Label>
                    <Select value={sortBy} onValueChange={setSortBy}>
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="newest">En Yeni</SelectItem>
                        <SelectItem value="price-low">Fiyat: Düşük-Yüksek</SelectItem>
                        <SelectItem value="price-high">Fiyat: Yüksek-Düşük</SelectItem>
                        <SelectItem value="popular">En Popüler</SelectItem>
                        <SelectItem value="rating">En Yüksek Puan</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Products Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <Card key={product.id} className="group hover:shadow-lg transition-shadow overflow-hidden">
                  <div className="relative aspect-square overflow-hidden">
                    <Image
                      src={product.images[0] || "/placeholder.svg"}
                      alt={product.title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute top-2 left-2 flex flex-col gap-1">
                      {getConditionBadge(product.condition)}
                    </div>
                    <div className="absolute top-2 right-2">
                      <button
                        onClick={() => toggleLike(product.id)}
                        className={`p-2 rounded-full backdrop-blur-sm transition-colors ${
                          product.isLiked ? "bg-red-500/80 text-white" : "bg-white/80 text-gray-600 hover:text-red-500"
                        }`}
                      >
                        <Heart className={`h-4 w-4 ${product.isLiked ? "fill-current" : ""}`} />
                      </button>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold mb-2 line-clamp-2">{product.title}</h3>
                    <p className="text-sm text-gray-600 mb-3 line-clamp-2">{product.description}</p>

                    <div className="flex items-center justify-between mb-3">
                      <span className="text-2xl font-bold text-primary">₺{product.price}</span>
                      <div className="flex items-center gap-1 text-sm text-gray-500">
                        <Eye className="h-4 w-4" />
                        <span>{product.views}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 mb-3">
                      <div className="flex items-center gap-1">
                        <User className="h-4 w-4 text-gray-400" />
                        <span className="text-sm text-gray-600">{product.sellerName}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm text-gray-600">
                          {product.sellerRating} ({product.sellerReviews})
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 mb-3 text-xs text-gray-500">
                      <span>{product.location}</span>
                      <span>•</span>
                      <span>{new Date(product.createdAt).toLocaleDateString("tr-TR")}</span>
                    </div>

                    <div className="flex items-center gap-2 mb-4">
                      {product.tags.slice(0, 2).map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                      {product.tags.length > 2 && (
                        <Badge variant="secondary" className="text-xs">
                          +{product.tags.length - 2}
                        </Badge>
                      )}
                    </div>

                    <div className="flex gap-2">
                      <Button className="flex-1" size="sm">
                        <ShoppingCart className="h-4 w-4 mr-1" />
                        Satın Al
                      </Button>
                      <Button size="sm" variant="outline">
                        <MessageCircle className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Share2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredProducts.length === 0 && (
              <div className="text-center py-12">
                <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Ürün bulunamadı</h3>
                <p className="text-gray-600">Seçtiğiniz filtrelere uygun ürün bulunmuyor.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="sell" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Ürün Sat
                </CardTitle>
                <CardDescription>
                  Deri ürününüzü pazaryerimizde satışa çıkarın. Admin onayından sonra ürününüz yayınlanacak.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* File Upload Area */}
                <div>
                  <Label className="text-base font-medium mb-3 block">Ürün Resimleri *</Label>
                  <div
                    className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-primary transition-colors cursor-pointer"
                    onDrop={handleDrop}
                    onDragOver={handleDragOver}
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <ImageIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">Ürün resimlerini buraya sürükleyin</h3>
                    <p className="text-gray-600 mb-4">veya dosya seçmek için tıklayın</p>
                    <Button variant="outline">
                      <Upload className="h-4 w-4 mr-2" />
                      Resim Seç
                    </Button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      multiple
                      accept="image/*"
                      onChange={handleFileSelect}
                      className="hidden"
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    Maksimum 8 resim, her biri en fazla 10MB. İlk resim ana resim olacaktır.
                  </p>
                </div>

                {/* Selected Files Preview */}
                {selectedFiles.length > 0 && (
                  <div className="space-y-4">
                    <h4 className="font-medium">Seçilen Resimler ({selectedFiles.length}/8)</h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                      {selectedFiles.map((file, index) => (
                        <div key={index} className="relative group">
                          <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
                            <Image
                              src={URL.createObjectURL(file) || "/placeholder.svg"}
                              alt={file.name}
                              width={200}
                              height={200}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          {index === 0 && <Badge className="absolute top-1 left-1 text-xs">Ana Resim</Badge>}
                          <button
                            onClick={() => removeFile(index)}
                            className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Product Form */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="title">Ürün Başlığı *</Label>
                      <Input
                        id="title"
                        value={productForm.title}
                        onChange={(e) => setProductForm((prev) => ({ ...prev, title: e.target.value }))}
                        placeholder="Ürününüzün başlığını girin"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="price">Fiyat (₺) *</Label>
                      <Input
                        id="price"
                        type="number"
                        min="0"
                        step="0.01"
                        value={productForm.price}
                        onChange={(e) => setProductForm((prev) => ({ ...prev, price: e.target.value }))}
                        placeholder="0.00"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="category">Kategori *</Label>
                      <Select
                        value={productForm.category}
                        onValueChange={(value) => setProductForm((prev) => ({ ...prev, category: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Kategori seçin" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map((category) => (
                            <SelectItem key={category.value} value={category.value}>
                              {category.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="condition">Ürün Durumu *</Label>
                      <Select
                        value={productForm.condition}
                        onValueChange={(value) => setProductForm((prev) => ({ ...prev, condition: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Durum seçin" />
                        </SelectTrigger>
                        <SelectContent>
                          {conditions.map((condition) => (
                            <SelectItem key={condition.value} value={condition.value}>
                              <div>
                                <div className="font-medium">{condition.label}</div>
                                <div className="text-xs text-gray-500">{condition.description}</div>
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="location">Konum</Label>
                      <Input
                        id="location"
                        value={productForm.location}
                        onChange={(e) => setProductForm((prev) => ({ ...prev, location: e.target.value }))}
                        placeholder="İl, İlçe"
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="description">Ürün Açıklaması *</Label>
                      <Textarea
                        id="description"
                        value={productForm.description}
                        onChange={(e) => setProductForm((prev) => ({ ...prev, description: e.target.value }))}
                        placeholder="Ürününüzü detaylı olarak açıklayın..."
                        rows={4}
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="tags">Etiketler</Label>
                      <Input
                        id="tags"
                        value={productForm.tags}
                        onChange={(e) => setProductForm((prev) => ({ ...prev, tags: e.target.value }))}
                        placeholder="el-yapımı, vintage, italyan-deri (virgülle ayırın)"
                      />
                    </div>

                    <div>
                      <Label className="text-base font-medium mb-3 block">Kargo Seçenekleri</Label>
                      <div className="space-y-2">
                        {["Kargo", "Elden Teslim", "Kurye"].map((option) => (
                          <div key={option} className="flex items-center space-x-2">
                            <input
                              type="checkbox"
                              id={option}
                              checked={productForm.shippingOptions.includes(option)}
                              onChange={(e) => handleShippingOptionChange(option, e.target.checked)}
                              className="rounded"
                            />
                            <Label htmlFor={option} className="text-sm">
                              {option}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="returnPolicy">İade Politikası</Label>
                      <Textarea
                        id="returnPolicy"
                        value={productForm.returnPolicy}
                        onChange={(e) => setProductForm((prev) => ({ ...prev, returnPolicy: e.target.value }))}
                        placeholder="İade koşullarınızı belirtin..."
                        rows={3}
                      />
                    </div>
                  </div>
                </div>

                {/* Guidelines */}
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Satış Kuralları:</strong>
                    <ul className="list-disc list-inside mt-2 space-y-1">
                      <li>Sadece deri ürünleri satışa çıkarabilirsiniz</li>
                      <li>Ürün açıklamaları doğru ve detaylı olmalıdır</li>
                      <li>Resimler ürünü net bir şekilde göstermelidir</li>
                      <li>Fiyatlandırma adil ve piyasaya uygun olmalıdır</li>
                      <li>Tüm ürünler admin onayından geçer</li>
                    </ul>
                  </AlertDescription>
                </Alert>

                {/* Submit Button */}
                <div className="flex justify-end">
                  <Button onClick={handleSubmitProduct} disabled={isSubmitting || selectedFiles.length === 0} size="lg">
                    {isSubmitting ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                        Gönderiliyor...
                      </>
                    ) : (
                      <>
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Onaya Gönder
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="my-products" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Ürünlerim</h2>
              <Badge variant="secondary">{userProducts.length} ürün</Badge>
            </div>

            {userProducts.length === 0 ? (
              <Card>
                <CardContent className="text-center py-12">
                  <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Henüz ürün eklemediniz</h3>
                  <p className="text-gray-600 mb-4">
                    İlk ürününüzü satışa çıkarmak için "Ürün Sat" sekmesini kullanın.
                  </p>
                  <Button onClick={() => setActiveTab("sell")}>
                    <TrendingUp className="h-4 w-4 mr-2" />
                    Ürün Ekle
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {userProducts.map((product) => (
                  <Card key={product.id} className="overflow-hidden">
                    <div className="relative aspect-square overflow-hidden">
                      <Image
                        src={product.images[0] || "/placeholder.svg"}
                        alt={product.title}
                        fill
                        className="object-cover"
                      />
                      <div className="absolute top-2 left-2">{getStatusBadge(product.status)}</div>
                      <div className="absolute top-2 right-2">{getConditionBadge(product.condition)}</div>
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-semibold mb-2 line-clamp-1">{product.title}</h3>
                      <p className="text-sm text-gray-600 mb-3 line-clamp-2">{product.description}</p>

                      <div className="flex items-center justify-between mb-3">
                        <span className="text-xl font-bold text-primary">₺{product.price}</span>
                        <div className="flex items-center gap-3 text-sm text-gray-500">
                          <div className="flex items-center gap-1">
                            <Eye className="h-4 w-4" />
                            <span>{product.views}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Heart className="h-4 w-4" />
                            <span>{product.likes}</span>
                          </div>
                        </div>
                      </div>

                      <div className="text-xs text-gray-500 mb-3">
                        Yayınlanma: {new Date(product.createdAt).toLocaleDateString("tr-TR")}
                      </div>

                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          Düzenle
                        </Button>
                        <Button variant="outline" size="sm" className="flex-1">
                          İstatistikler
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
