"use client"

import type React from "react"

import { useState, useRef, useCallback } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Upload,
  X,
  ImageIcon,
  User,
  Calendar,
  Heart,
  MessageCircle,
  Share2,
  Download,
  AlertCircle,
  CheckCircle,
} from "lucide-react"
import { useAuth } from "@/components/auth-provider"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"

interface UploadedImage {
  id: string
  url: string
  title: string
  description: string
  uploadedBy: string
  uploadedAt: string
  likes: number
  comments: number
  tags: string[]
  isLiked: boolean
}

// Mock uploaded images data
const mockUploadedImages: UploadedImage[] = [
  {
    id: "1",
    url: "/placeholder.svg?height=400&width=400",
    title: "El Yapımı Deri Cüzdan",
    description: "Yeni tamamladığım vintage tarzı deri cüzdan. İtalyan derisi kullandım.",
    uploadedBy: "Ahmet Yılmaz",
    uploadedAt: "2024-01-15",
    likes: 24,
    comments: 8,
    tags: ["cüzdan", "vintage", "el-yapımı"],
    isLiked: false,
  },
  {
    id: "2",
    url: "/placeholder.svg?height=400&width=400",
    title: "Deri Çanta Koleksiyonu",
    description: "Son projelerimden bazıları. Farklı renk ve tarzlarda çantalar.",
    uploadedBy: "Zeynep Kaya",
    uploadedAt: "2024-01-12",
    likes: 45,
    comments: 12,
    tags: ["çanta", "koleksiyon", "renkli"],
    isLiked: true,
  },
  {
    id: "3",
    url: "/placeholder.svg?height=400&width=400",
    title: "Atölye Çalışması",
    description: "Bugünkü atölye çalışmamdan bir kare. Yeni teknikleri deniyorum.",
    uploadedBy: "Mehmet Özkan",
    uploadedAt: "2024-01-10",
    likes: 18,
    comments: 5,
    tags: ["atölye", "çalışma", "teknik"],
    isLiked: false,
  },
  {
    id: "4",
    url: "/placeholder.svg?height=400&width=400",
    title: "Deri Kemer Detayı",
    description: "El dikişi detayları ve pirinç toka ile tamamlanan deri kemer.",
    uploadedBy: "Ayşe Demir",
    uploadedAt: "2024-01-08",
    likes: 32,
    comments: 7,
    tags: ["kemer", "detay", "pirinç"],
    isLiked: true,
  },
]

export default function GalleryPage() {
  const { user, isAuthenticated } = useAuth()
  const { toast } = useToast()
  const router = useRouter()
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [selectedFiles, setSelectedFiles] = useState<File[]>([])
  const [uploadForm, setUploadForm] = useState({
    title: "",
    description: "",
    tags: "",
  })
  const [isUploading, setIsUploading] = useState(false)
  const [uploadedImages, setUploadedImages] = useState<UploadedImage[]>(mockUploadedImages)
  const [activeTab, setActiveTab] = useState("gallery")

  // Redirect if not authenticated
  if (!isAuthenticated) {
    router.push("/auth/login")
    return null
  }

  const handleFileSelect = useCallback(
    (event: React.ChangeEvent<HTMLInputElement>) => {
      const files = Array.from(event.target.files || [])
      const validFiles = files.filter((file) => {
        const isValidType = file.type.startsWith("image/")
        const isValidSize = file.size <= 10 * 1024 * 1024 // 10MB limit

        if (!isValidType) {
          toast({
            title: "Geçersiz dosya türü",
            description: "Sadece resim dosyaları yükleyebilirsiniz.",
            variant: "destructive",
          })
          return false
        }

        if (!isValidSize) {
          toast({
            title: "Dosya çok büyük",
            description: "Dosya boyutu 10MB'dan küçük olmalıdır.",
            variant: "destructive",
          })
          return false
        }

        return true
      })

      setSelectedFiles((prev) => [...prev, ...validFiles].slice(0, 5)) // Max 5 files
    },
    [toast],
  )

  const handleDrop = useCallback(
    (event: React.DragEvent) => {
      event.preventDefault()
      const files = Array.from(event.dataTransfer.files)
      const fakeEvent = {
        target: { files },
      } as React.ChangeEvent<HTMLInputElement>
      handleFileSelect(fakeEvent)
    },
    [handleFileSelect],
  )

  const handleDragOver = useCallback((event: React.DragEvent) => {
    event.preventDefault()
  }, [])

  const removeFile = (index: number) => {
    setSelectedFiles((prev) => prev.filter((_, i) => i !== index))
  }

  const handleUpload = async () => {
    if (selectedFiles.length === 0) {
      toast({
        title: "Dosya seçin",
        description: "Yüklemek için en az bir resim seçmelisiniz.",
        variant: "destructive",
      })
      return
    }

    if (!uploadForm.title.trim()) {
      toast({
        title: "Başlık gerekli",
        description: "Lütfen resimleriniz için bir başlık girin.",
        variant: "destructive",
      })
      return
    }

    setIsUploading(true)

    try {
      // Simulate upload process
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Create new uploaded image entries
      const newImages: UploadedImage[] = selectedFiles.map((file, index) => ({
        id: Date.now().toString() + index,
        url: URL.createObjectURL(file),
        title: uploadForm.title,
        description: uploadForm.description,
        uploadedBy: `${user?.firstName} ${user?.lastName}`,
        uploadedAt: new Date().toISOString().split("T")[0],
        likes: 0,
        comments: 0,
        tags: uploadForm.tags
          .split(",")
          .map((tag) => tag.trim())
          .filter(Boolean),
        isLiked: false,
      }))

      setUploadedImages((prev) => [...newImages, ...prev])
      setSelectedFiles([])
      setUploadForm({ title: "", description: "", tags: "" })
      setActiveTab("gallery")

      toast({
        title: "Yükleme başarılı!",
        description: `${selectedFiles.length} resim başarıyla yüklendi.`,
      })
    } catch (error) {
      toast({
        title: "Yükleme hatası",
        description: "Resimler yüklenirken bir hata oluştu.",
        variant: "destructive",
      })
    } finally {
      setIsUploading(false)
    }
  }

  const toggleLike = (imageId: string) => {
    setUploadedImages((prev) =>
      prev.map((img) =>
        img.id === imageId
          ? {
              ...img,
              isLiked: !img.isLiked,
              likes: img.isLiked ? img.likes - 1 : img.likes + 1,
            }
          : img,
      ),
    )
  }

  return (
    <>
      {isAuthenticated ? (
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold mb-4">Üye Galerisi</h1>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Deri sanatı çalışmalarınızı paylaşın ve diğer üyelerimizin eserlerini keşfedin
              </p>
            </div>

            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="gallery">Galeri</TabsTrigger>
                <TabsTrigger value="upload">Resim Yükle</TabsTrigger>
              </TabsList>

              <TabsContent value="gallery" className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {uploadedImages.map((image) => (
                    <Card key={image.id} className="group hover:shadow-lg transition-shadow overflow-hidden">
                      <div className="relative aspect-square overflow-hidden">
                        <Image
                          src={image.url || "/placeholder.svg"}
                          alt={image.title}
                          fill
                          className="object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                          <div className="absolute bottom-4 left-4 right-4">
                            <div className="flex items-center gap-2 mb-2">
                              {image.tags.map((tag) => (
                                <Badge key={tag} variant="secondary" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <h3 className="font-semibold mb-2 line-clamp-1">{image.title}</h3>
                        <p className="text-sm text-gray-600 mb-3 line-clamp-2">{image.description}</p>

                        <div className="flex items-center justify-between text-sm text-gray-500 mb-3">
                          <div className="flex items-center gap-1">
                            <User className="h-4 w-4" />
                            <span>{image.uploadedBy}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            <span>{new Date(image.uploadedAt).toLocaleDateString("tr-TR")}</span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <button
                              onClick={() => toggleLike(image.id)}
                              className={`flex items-center gap-1 transition-colors ${
                                image.isLiked ? "text-red-500" : "text-gray-500 hover:text-red-500"
                              }`}
                            >
                              <Heart className={`h-4 w-4 ${image.isLiked ? "fill-current" : ""}`} />
                              <span className="text-sm">{image.likes}</span>
                            </button>
                            <div className="flex items-center gap-1 text-gray-500">
                              <MessageCircle className="h-4 w-4" />
                              <span className="text-sm">{image.comments}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Button size="sm" variant="ghost">
                              <Share2 className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="ghost">
                              <Download className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="upload" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Upload className="h-5 w-5" />
                      Resim Yükle
                    </CardTitle>
                    <CardDescription>Deri sanatı çalışmalarınızı diğer üyelerle paylaşın</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* File Upload Area */}
                    <div
                      className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-primary transition-colors cursor-pointer"
                      onDrop={handleDrop}
                      onDragOver={handleDragOver}
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <ImageIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium mb-2">Resimlerinizi buraya sürükleyin</h3>
                      <p className="text-gray-600 mb-4">veya dosya seçmek için tıklayın</p>
                      <Button variant="outline">
                        <Upload className="h-4 w-4 mr-2" />
                        Dosya Seç
                      </Button>
                      <input
                        ref={fileInputRef}
                        type="file"
                        multiple
                        accept="image/*"
                        onChange={handleFileSelect}
                        className="hidden"
                      />
                    </div>

                    {/* File Upload Guidelines */}
                    <Alert>
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>
                        <strong>Yükleme Kuralları:</strong>
                        <ul className="list-disc list-inside mt-2 space-y-1">
                          <li>Maksimum 5 resim yükleyebilirsiniz</li>
                          <li>Her dosya en fazla 10MB olabilir</li>
                          <li>Sadece JPG, PNG, GIF formatları desteklenir</li>
                          <li>Deri sanatı ile ilgili içerikler paylaşın</li>
                        </ul>
                      </AlertDescription>
                    </Alert>

                    {/* Selected Files Preview */}
                    {selectedFiles.length > 0 && (
                      <div className="space-y-4">
                        <h4 className="font-medium">Seçilen Dosyalar ({selectedFiles.length}/5)</h4>
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                          {selectedFiles.map((file, index) => (
                            <div key={index} className="relative group">
                              <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
                                <Image
                                  src={URL.createObjectURL(file) || "/placeholder.svg"}
                                  alt={file.name}
                                  width={200}
                                  height={200}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <button
                                onClick={() => removeFile(index)}
                                className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                <X className="h-4 w-4" />
                              </button>
                              <p className="text-xs text-gray-600 mt-1 truncate">{file.name}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Upload Form */}
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="title">Başlık *</Label>
                        <Input
                          id="title"
                          value={uploadForm.title}
                          onChange={(e) => setUploadForm((prev) => ({ ...prev, title: e.target.value }))}
                          placeholder="Resimleriniz için bir başlık girin"
                          required
                        />
                      </div>

                      <div>
                        <Label htmlFor="description">Açıklama</Label>
                        <Textarea
                          id="description"
                          value={uploadForm.description}
                          onChange={(e) => setUploadForm((prev) => ({ ...prev, description: e.target.value }))}
                          placeholder="Çalışmanız hakkında detaylar paylaşın..."
                          rows={3}
                        />
                      </div>

                      <div>
                        <Label htmlFor="tags">Etiketler</Label>
                        <Input
                          id="tags"
                          value={uploadForm.tags}
                          onChange={(e) => setUploadForm((prev) => ({ ...prev, tags: e.target.value }))}
                          placeholder="cüzdan, el-yapımı, vintage (virgülle ayırın)"
                        />
                        <p className="text-xs text-gray-500 mt-1">
                          Etiketler diğer üyelerin çalışmanızı bulmasına yardımcı olur
                        </p>
                      </div>
                    </div>

                    {/* Upload Button */}
                    <div className="flex justify-end">
                      <Button onClick={handleUpload} disabled={isUploading || selectedFiles.length === 0} size="lg">
                        {isUploading ? (
                          <>
                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                            Yükleniyor...
                          </>
                        ) : (
                          <>
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Yükle
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      ) : null}
    </>
  )
}
