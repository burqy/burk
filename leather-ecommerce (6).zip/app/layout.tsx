import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { CartProvider } from "@/components/cart-provider"
import { AuthProvider } from "@/components/auth-provider"
import { LanguageProvider } from "@/components/language-provider"
import { Toaster } from "@/components/ui/toaster"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Premium Deri Ürünleri - El Yapımı Kalite",
  description:
    "Premium el yapımı deri ürünleri koleksiyonumuzu ve uzman dijital rehberlerimizi keşfedin. Seçkin müşteriler için kaliteli deri ürünleri.",
  keywords: "deri ürünleri, el yapımı, premium, çanta, cüzdan, aksesuar, deri bakımı",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="tr">
      <body className={`${inter.className} select-none`} onContextMenu={(e) => e.preventDefault()}>
        <LanguageProvider>
          <AuthProvider>
            <CartProvider>
              <Header />
              <main>{children}</main>
              <Footer />
              <Toaster />
            </CartProvider>
          </AuthProvider>
        </LanguageProvider>
      </body>
    </html>
  )
}
