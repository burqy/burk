"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useCart } from "@/components/cart-provider"
import { useAuth } from "@/components/auth-provider"
import { CreditCard, Lock, Truck, Download, AlertTriangle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"
import { useLanguage } from "@/components/language-provider"

export default function CheckoutPage() {
  const { items, total, clearCart } = useCart()
  const { isAuthenticated, user } = useAuth()
  const { toast } = useToast()
  const router = useRouter()
  const [isProcessing, setIsProcessing] = useState(false)
  const { t, formatPrice } = useLanguage()

  const physicalItems = items.filter((item) => item.type === "physical")
  const digitalItems = items.filter((item) => item.type === "digital")
  const shippingCost = physicalItems.length > 0 ? 9.99 : 0
  const finalTotal = total + shippingCost

  // Check if user is authenticated for digital products
  const hasDigitalItems = digitalItems.length > 0
  const canProceed = !hasDigitalItems || isAuthenticated

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!canProceed) {
      toast({
        title: "Giriş Gerekli",
        description: "Dijital ürünleri satın almak için giriş yapmanız gerekiyor.",
        variant: "destructive",
      })
      return
    }

    setIsProcessing(true)

    // Ödeme işlemini simüle et
    setTimeout(() => {
      toast({
        title: "Sipariş başarıyla verildi!",
        description: hasDigitalItems
          ? "Dijital ürünlerinizin indirme bağlantıları e-postanıza gönderildi."
          : "Kısa süre içinde onay e-postası alacaksınız.",
      })
      clearCart()
      setIsProcessing(false)
      router.push("/")
    }, 2000)
  }

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">{t("header.cartEmpty")}</h1>
        <p className="text-gray-600 mb-8">Ödeme işlemine devam etmek için sepetinize ürün ekleyin.</p>
        <Button asChild>
          <a href="/products">Alışverişe Devam Et</a>
        </Button>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">{t("checkout.payment")}</h1>

      {/* Authentication warning for digital products */}
      {hasDigitalItems && !isAuthenticated && (
        <Alert className="mb-6 border-red-200 bg-red-50">
          <AlertTriangle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            <strong>Dikkat:</strong> Sepetinizde dijital ürünler bulunuyor. Bu ürünleri satın almak için
            <Button variant="link" className="p-0 h-auto text-red-800 underline ml-1" asChild>
              <a href="/auth/login">giriş yapmanız</a>
            </Button>{" "}
            gerekiyor.
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Ödeme Formu */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Ödeme Bilgileri
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">Ad</Label>
                    <Input id="firstName" defaultValue={user?.firstName || ""} required disabled={!canProceed} />
                  </div>
                  <div>
                    <Label htmlFor="lastName">Soyad</Label>
                    <Input id="lastName" defaultValue={user?.lastName || ""} required disabled={!canProceed} />
                  </div>
                </div>

                <div>
                  <Label htmlFor="email">E-posta</Label>
                  <Input id="email" type="email" defaultValue={user?.email || ""} required disabled={!canProceed} />
                  {hasDigitalItems && (
                    <p className="text-xs text-gray-500 mt-1">
                      Dijital ürünlerin indirme bağlantıları bu adrese gönderilecek
                    </p>
                  )}
                </div>

                <div>
                  <Label htmlFor="cardNumber">Kart Numarası</Label>
                  <Input id="cardNumber" placeholder="1234 5678 9012 3456" required disabled={!canProceed} />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="expiry">Son Kullanma</Label>
                    <Input id="expiry" placeholder="AA/YY" required disabled={!canProceed} />
                  </div>
                  <div>
                    <Label htmlFor="cvv">CVV</Label>
                    <Input id="cvv" placeholder="123" required disabled={!canProceed} />
                  </div>
                </div>

                {physicalItems.length > 0 && (
                  <>
                    <Separator />
                    <h3 className="font-semibold flex items-center gap-2">
                      <Truck className="h-5 w-5" />
                      Teslimat Adresi
                    </h3>

                    <div>
                      <Label htmlFor="address">Adres</Label>
                      <Input id="address" defaultValue={user?.address || ""} required disabled={!canProceed} />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="city">Şehir</Label>
                        <Input id="city" defaultValue={user?.city || ""} required disabled={!canProceed} />
                      </div>
                      <div>
                        <Label htmlFor="zipCode">Posta Kodu</Label>
                        <Input id="zipCode" required disabled={!canProceed} />
                      </div>
                    </div>
                  </>
                )}

                <Button type="submit" className="w-full" size="lg" disabled={isProcessing || !canProceed}>
                  <Lock className="mr-2 h-4 w-4" />
                  {isProcessing ? "İşleniyor..." : !canProceed ? "Giriş Yapın" : `${formatPrice(finalTotal)} Öde`}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Sipariş Özeti */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Sipariş Özeti</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {items.map((item) => (
                <div key={item.id} className="flex justify-between items-center">
                  <div className="flex-1">
                    <h4 className="font-medium">{item.name}</h4>
                    <div className="flex items-center gap-2">
                      <Badge variant={item.type === "digital" ? "secondary" : "default"}>
                        {item.type === "digital" ? t("product.digital") : t("product.physical")}
                      </Badge>
                      <span className="text-sm text-gray-600">Adet: {item.quantity}</span>
                    </div>
                  </div>
                  <span className="font-medium">{formatPrice(item.price * item.quantity)}</span>
                </div>
              ))}

              <Separator />

              <div className="flex justify-between">
                <span>Ara Toplam</span>
                <span>{formatPrice(total)}</span>
              </div>

              {shippingCost > 0 && (
                <div className="flex justify-between">
                  <span>Kargo</span>
                  <span>{formatPrice(shippingCost)}</span>
                </div>
              )}

              <Separator />

              <div className="flex justify-between font-bold text-lg">
                <span>Toplam</span>
                <span>{formatPrice(finalTotal)}</span>
              </div>
            </CardContent>
          </Card>

          {/* Teslimat Bilgileri */}
          <Card>
            <CardHeader>
              <CardTitle>Teslimat Bilgileri</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {digitalItems.length > 0 && (
                <div className="flex items-start gap-3">
                  <Download className="h-5 w-5 text-green-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium">Dijital Ürünler</h4>
                    <p className="text-sm text-gray-600">
                      Ödeme onayından sonra 5 dakika içinde güvenli indirme bağlantısı e-postanıza gönderilir
                    </p>
                    {!isAuthenticated && (
                      <p className="text-sm text-red-600 mt-1">⚠️ Dijital ürünler için giriş yapmanız gerekiyor</p>
                    )}
                  </div>
                </div>
              )}

              {physicalItems.length > 0 && (
                <div className="flex items-start gap-3">
                  <Truck className="h-5 w-5 text-blue-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium">Fiziksel Ürünler</h4>
                    <p className="text-sm text-gray-600">Standart kargo (5-7 iş günü)</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Digital Product Security Notice */}
          {digitalItems.length > 0 && (
            <Card className="border-blue-200 bg-blue-50">
              <CardHeader>
                <CardTitle className="text-blue-800 flex items-center gap-2">
                  <Lock className="h-5 w-5" />
                  Dijital Ürün Güvenliği
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-blue-800 space-y-2 text-sm">
                  <p>• İndirme bağlantıları şifre korumalıdır</p>
                  <p>• 30 gün boyunca indirme erişimi</p>
                  <p>• Telif hakkı koruması altındadır</p>
                  <p>• İzinsiz paylaşım yasaktır</p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
