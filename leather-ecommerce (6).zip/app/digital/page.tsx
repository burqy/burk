import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ShoppingCart, Star, FileText, Lock, Eye } from "lucide-react"

const digitalProducts = [
  {
    id: 3,
    name: "Deri Bakım Rehberi (PDF)",
    price: 9.99,
    image: "/placeholder.svg?height=300&width=300",
    rating: 4.7,
    reviews: 256,
    description: "Deri bakımı ve korunması için kapsamlı rehber",
    pages: 52,
    fileSize: "15 MB",
  },
  {
    id: 5,
    name: "Deri İşçiliği Eğitimi (PDF)",
    price: 19.99,
    image: "/placeholder.svg?height=300&width=300",
    rating: 4.8,
    reviews: 145,
    description: "Yeni başlayanlar için adım adım deri işçiliği eğitimi",
    pages: 78,
    fileSize: "25 MB",
  },
  {
    id: 7,
    name: "İleri Deri Teknikleri (PDF)",
    price: 29.99,
    image: "/placeholder.svg?height=300&width=300",
    rating: 4.9,
    reviews: 89,
    description: "Profesyonel deri işleme teknikleri ve kalıpları",
    pages: 124,
    fileSize: "40 MB",
  },
  {
    id: 8,
    name: "Deri İşi Başlangıç Kiti (PDF)",
    price: 39.99,
    image: "/placeholder.svg?height=300&width=300",
    rating: 4.6,
    reviews: 67,
    description: "Deri işçiliği işinizi başlatmak için kapsamlı rehber",
    pages: 96,
    fileSize: "30 MB",
  },
]

export default function DigitalProductsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      {/* Başlık */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Dijital Ürünler</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Deri işçiliği ve bakımında ustalaşmanıza yardımcı olacak uzman rehberleri ve eğitimleri
        </p>
      </div>

      {/* Avantajlar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <Card className="text-center">
          <CardContent className="pt-6">
            <Lock className="h-12 w-12 mx-auto mb-4 text-primary" />
            <h3 className="font-semibold mb-2">Güvenli Satın Alma</h3>
            <p className="text-sm text-gray-600">Satın alma sonrası güvenli indirme bağlantısı</p>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardContent className="pt-6">
            <FileText className="h-12 w-12 mx-auto mb-4 text-primary" />
            <h3 className="font-semibold mb-2">Yüksek Kalite PDF'ler</h3>
            <p className="text-sm text-gray-600">Detaylı illüstrasyonlarla profesyonel düzen</p>
          </CardContent>
        </Card>

        <Card className="text-center">
          <CardContent className="pt-6">
            <Star className="h-12 w-12 mx-auto mb-4 text-primary" />
            <h3 className="font-semibold mb-2">Uzman İçerik</h3>
            <p className="text-sm text-gray-600">Usta deri işçileri tarafından hazırlandı</p>
          </CardContent>
        </Card>
      </div>

      {/* Ürün Listesi */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {digitalProducts.map((product) => (
          <Card key={product.id} className="group hover:shadow-lg transition-shadow">
            <CardHeader className="p-0">
              <div className="relative overflow-hidden rounded-t-lg">
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  width={300}
                  height={300}
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <Badge className="absolute top-2 right-2" variant="secondary">
                  Dijital
                </Badge>
                <div className="absolute top-2 left-2 bg-red-500 text-white px-2 py-1 rounded text-xs font-medium">
                  <Lock className="h-3 w-3 inline mr-1" />
                  Korumalı
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-4">
              <div className="flex items-center gap-1 mb-2">
                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                <span className="text-sm text-gray-600">
                  {product.rating} ({product.reviews})
                </span>
              </div>
              <CardTitle className="text-lg mb-2">{product.name}</CardTitle>
              <p className="text-sm text-gray-600 mb-3">{product.description}</p>

              <div className="flex justify-between text-xs text-gray-500 mb-3">
                <span>{product.pages} sayfa</span>
                <span>{product.fileSize}</span>
              </div>

              <p className="text-2xl font-bold text-gray-900">₺{product.price}</p>
            </CardContent>
            <CardFooter className="p-4 pt-0 flex gap-2">
              <Button asChild className="flex-1">
                <Link href={`/products/${product.id}`}>
                  <Eye className="mr-2 h-4 w-4" />
                  Detayları Gör
                </Link>
              </Button>
              <Button size="icon" variant="outline">
                <ShoppingCart className="h-4 w-4" />
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {/* Güvenlik Bilgileri */}
      <div className="mt-16 bg-blue-50 rounded-lg p-6">
        <div className="flex items-start gap-4">
          <Lock className="h-8 w-8 text-blue-600 mt-1" />
          <div>
            <h3 className="text-xl font-bold text-blue-900 mb-2">Dijital Ürün Güvenliği</h3>
            <div className="text-blue-800 space-y-2">
              <p>• Tüm dijital ürünlerimiz telif hakkı koruması altındadır</p>
              <p>• İndirme bağlantıları sadece satın alma sonrası aktif hale gelir</p>
              <p>• Her satın alma için benzersiz indirme bağlantısı oluşturulur</p>
              <p>• İndirme bağlantıları 30 gün boyunca geçerlidir</p>
              <p>• Ürünlerin izinsiz paylaşımı yasal işlem gerektirir</p>
            </div>
          </div>
        </div>
      </div>

      {/* SSS Bölümü */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold text-center mb-8">Sık Sorulan Sorular</h2>
        <div className="max-w-3xl mx-auto space-y-6">
          <Card>
            <CardContent className="p-6">
              <h3 className="font-semibold mb-2">Satın aldığım ürünü nasıl indirebilirim?</h3>
              <p className="text-gray-600">
                Satın alma işleminizi tamamladıktan sonra, güvenli indirme bağlantısı içeren bir e-posta alacaksınız.
                Ayrıca hesap panelinizden de indirmelerinize erişebilirsiniz.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h3 className="font-semibold mb-2">İndirme bağlantısı ne kadar süre geçerli?</h3>
              <p className="text-gray-600">
                İndirme bağlantılarınız satın alma tarihinden itibaren 30 gün boyunca geçerlidir. Bu süre içinde
                istediğiniz kadar indirebilirsiniz.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h3 className="font-semibold mb-2">Dijital ürünler hangi formatta?</h3>
              <p className="text-gray-600">
                Tüm dijital ürünlerimiz bilgisayar, tablet ve akıllı telefon dahil her cihazda çalışan yüksek kaliteli
                PDF dosyalarıdır. Dosyalar şifre korumalı olarak gönderilir.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h3 className="font-semibold mb-2">PDF'leri yazdırabilir miyim?</h3>
              <p className="text-gray-600">
                Evet! Satın aldığınız PDF'leri kişisel kullanım için yazdırabilirsiniz. Ancak ticari amaçlı çoğaltma ve
                dağıtım yasaktır.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h3 className="font-semibold mb-2">İndirme bağlantısını kaybettim, ne yapmalıyım?</h3>
              <p className="text-gray-600">
                Hesap panelinizden "Dijital Ürünlerim" bölümünden tüm satın aldığınız ürünlere erişebilirsiniz. Sorun
                yaşarsanız müşteri hizmetlerimizle iletişime geçin.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
