"use client"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ShoppingCart, Star, Play, Clock, Eye } from "lucide-react"
import { HeroCarousel } from "@/components/hero-carousel"
import { VideoPlayerModal } from "@/components/video-player-modal"
import { useEffect, useRef, useState } from "react"
import { useLanguage } from "@/components/language-provider"

// Mock carousel data - gerçek uygulamada bu veriler CMS'den gelecek
const carouselItems = [
  {
    id: 1,
    type: "image" as const,
    src: "/placeholder.svg?height=600&width=1200",
    thumbnailSrc: "/placeholder.svg?height=100&width=200", // Low-res thumbnail
    alt: "Premium Deri Koleksiyonu",
    title: "Premium Deri Koleksiyonu",
    description: "El yapımı deri ürünlerimizle tarzınızı yansıtın",
    buttonText: "Koleksiyonu Keşfet",
    buttonLink: "/products",
  },
  {
    id: 2,
    type: "image" as const,
    src: "/placeholder.svg?height=600&width=1200",
    thumbnailSrc: "/placeholder.svg?height=100&width=200", // Low-res thumbnail
    alt: "Deri İşçiliği Sanatı",
    title: "Deri İşçiliği Sanatı",
    description: "Usta zanaatkarlarımızın elinden çıkan eşsiz ürünler",
    buttonText: "Nasıl Yapıyoruz?",
    buttonLink: "/about",
  },
  {
    id: 3,
    type: "image" as const,
    src: "/placeholder.svg?height=600&width=1200",
    thumbnailSrc: "/placeholder.svg?height=100&width=200", // Low-res thumbnail
    alt: "Yeni Sezon Çantalar",
    title: "Yeni Sezon Çantalar",
    description: "2024 koleksiyonumuzdan özel tasarımlar",
    buttonText: "Hemen İncele",
    buttonLink: "/products?category=çantalar",
  },
]

// Mock data - gerçek uygulamada bu veriler veritabanından gelecek
const featuredProducts = [
  {
    id: 1,
    name: "Premium Deri Cüzdan",
    price: 89.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Cüzdanlar",
    type: "physical",
    rating: 4.8,
    reviews: 124,
  },
  {
    id: 2,
    name: "El Yapımı Deri Çanta",
    price: 249.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Çantalar",
    type: "physical",
    rating: 4.9,
    reviews: 89,
  },
  {
    id: 3,
    name: "Deri Bakım Rehberi (PDF)",
    price: 9.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Dijital",
    type: "digital",
    rating: 4.7,
    reviews: 256,
  },
  {
    id: 4,
    name: "Deri Kemer",
    price: 59.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Aksesuarlar",
    type: "physical",
    rating: 4.6,
    reviews: 78,
  },
  {
    id: 5,
    name: "Deri İşçiliği Eğitimi (PDF)",
    price: 19.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Dijital",
    type: "digital",
    rating: 4.8,
    reviews: 145,
  },
  {
    id: 6,
    name: "Yönetici Evrak Çantası",
    price: 399.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Çantalar",
    type: "physical",
    rating: 4.9,
    reviews: 67,
  },
  {
    id: 7,
    name: "Minimalist Deri Cüzdan",
    price: 49.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Cüzdanlar",
    type: "physical",
    rating: 4.5,
    reviews: 156,
  },
  {
    id: 8,
    name: "RFID Korumalı Kart Tutucu",
    price: 29.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "Kart Tutucular",
    type: "physical",
    rating: 4.7,
    reviews: 203,
  },
]

// Mock video data
const featuredVideos = [
  {
    id: 1,
    title: "Deri Cüzdan Yapım Süreci",
    description:
      "El yapımı deri cüzdan üretiminin tüm aşamalarını izleyin. Bu videoda, deri seçiminden son ürüne kadar olan tüm süreçleri detaylı bir şekilde gösteriyoruz.",
    thumbnail: "/placeholder.svg?height=300&width=400",
    duration: "8:45",
    views: 15420,
    videoUrl: "https://cdn.plyr.io/static/demo/View_From_A_Blue_Moon_Trailer-720p.mp4",
  },
  {
    id: 2,
    title: "Deri Bakım Teknikleri",
    description:
      "Deri ürünlerinizi nasıl bakım yapacağınızı öğrenin. Uzman ipuçları ve doğru bakım teknikleri ile ürünlerinizin ömrünü uzatın.",
    thumbnail: "/placeholder.svg?height=300&width=400",
    duration: "12:30",
    views: 8750,
    videoUrl: "https://cdn.plyr.io/static/demo/View_From_A_Blue_Moon_Trailer-720p.mp4",
  },
  {
    id: 3,
    title: "Atölye Turu",
    description:
      "DeriSanat atölyesinde bir gün geçirin. Ustalarımızın çalışma şeklini ve kullandığımız geleneksel teknikleri keşfedin.",
    thumbnail: "/placeholder.svg?height=300&width=400",
    duration: "15:20",
    views: 22100,
    videoUrl: "https://cdn.plyr.io/static/demo/View_From_A_Blue_Moon_Trailer-720p.mp4",
  },
  {
    id: 4,
    title: "Müşteri Hikayeleri",
    description: "Müşterilerimizin DeriSanat deneyimleri ve ürünlerimizle yaşadıkları özel anları dinleyin.",
    thumbnail: "/placeholder.svg?height=300&width=400",
    duration: "6:15",
    views: 5680,
    videoUrl: "https://cdn.plyr.io/static/demo/View_From_A_Blue_Moon_Trailer-720p.mp4",
  },
]

// Parallax decoration images
const parallaxDecorations = [
  {
    src: "/placeholder.svg?height=200&width=200",
    alt: "Leather texture",
    className: "absolute -top-20 -left-10 w-40 h-40 opacity-20 rotate-12",
    speed: 0.05,
  },
  {
    src: "/placeholder.svg?height=300&width=300",
    alt: "Leather tools",
    className: "absolute top-40 -right-20 w-60 h-60 opacity-10 -rotate-15",
    speed: 0.08,
  },
  {
    src: "/placeholder.svg?height=150&width=150",
    alt: "Leather pattern",
    className: "absolute bottom-20 -left-10 w-32 h-32 opacity-15 rotate-45",
    speed: 0.06,
  },
  {
    src: "/placeholder.svg?height=250&width=250",
    alt: "Leather stitching",
    className: "absolute -bottom-10 right-20 w-48 h-48 opacity-10 -rotate-20",
    speed: 0.07,
  },
]

export default function HomePage() {
  const [isVisible, setIsVisible] = useState(false)
  const [isVideoVisible, setIsVideoVisible] = useState(false)
  const [selectedVideoIndex, setSelectedVideoIndex] = useState<number | null>(null)
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false)
  const [scrollY, setScrollY] = useState(0)

  const featuredRef = useRef<HTMLElement>(null)
  const videoRef = useRef<HTMLElement>(null)
  const categoryRef = useRef<HTMLElement>(null)
  const aboutRef = useRef<HTMLElement>(null)

  const parallaxRefs = {
    featured: useRef<HTMLDivElement>(null),
    video: useRef<HTMLDivElement>(null),
    category: useRef<HTMLDivElement>(null),
    about: useRef<HTMLDivElement>(null),
  }

  const { t, formatPrice } = useLanguage()

  // Handle scroll for parallax effect
  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY)
    }

    window.addEventListener("scroll", handleScroll, { passive: true })
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    // Initial animation on page load
    const timer = setTimeout(() => {
      setIsVisible(true)
    }, 300)

    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.target === featuredRef.current) {
            setIsVisible(entry.isIntersecting)
          }
          if (entry.target === videoRef.current) {
            setIsVideoVisible(entry.isIntersecting)
          }
        })
      },
      {
        threshold: 0.1,
        rootMargin: "50px",
      },
    )

    if (featuredRef.current) {
      observer.observe(featuredRef.current)
    }
    if (videoRef.current) {
      observer.observe(videoRef.current)
    }

    return () => {
      if (featuredRef.current) {
        observer.unobserve(featuredRef.current)
      }
      if (videoRef.current) {
        observer.unobserve(videoRef.current)
      }
    }
  }, [])

  const handleVideoClick = (index: number) => {
    setSelectedVideoIndex(index)
    setIsVideoModalOpen(true)
  }

  const handleCloseVideoModal = () => {
    setIsVideoModalOpen(false)
    setSelectedVideoIndex(null)
  }

  const handleNextVideo = () => {
    if (selectedVideoIndex !== null && selectedVideoIndex < featuredVideos.length - 1) {
      setSelectedVideoIndex(selectedVideoIndex + 1)
    }
  }

  const handlePreviousVideo = () => {
    if (selectedVideoIndex !== null && selectedVideoIndex > 0) {
      setSelectedVideoIndex(selectedVideoIndex - 1)
    }
  }

  const currentVideo = selectedVideoIndex !== null ? featuredVideos[selectedVideoIndex] : null

  // Calculate parallax transforms
  const getParallaxStyle = (speed: number, offset = 0) => {
    return {
      transform: `translateY(${scrollY * speed + offset}px)`,
    }
  }

  return (
    <div className="min-h-screen bg-background overflow-x-hidden">
      {/* Hero Carousel */}
      <HeroCarousel items={carouselItems} />

      {/* Öne Çıkan Ürünler */}
      <section ref={featuredRef} className="py-16 relative" aria-labelledby="featured-products-heading">
        {/* Parallax decorative elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
          <div ref={parallaxRefs.featured} className="absolute inset-0" style={getParallaxStyle(-0.05)}>
            <div className="absolute top-10 left-10 w-40 h-40 rounded-full bg-primary/5 blur-3xl"></div>
            <div className="absolute bottom-20 right-20 w-60 h-60 rounded-full bg-primary/5 blur-3xl"></div>
          </div>
        </div>

        <div className="container mx-auto px-4 relative">
          <div className="text-center mb-12" style={getParallaxStyle(0.03)}>
            <h2 id="featured-products-heading" className="text-3xl font-bold text-gray-900 mb-4">
              {t("homepage.featuredProducts")}
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">{t("homepage.featuredProductsDesc")}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product, index) => (
              <Card
                key={product.id}
                className={`group hover:shadow-lg transition-all duration-700 transform ${
                  isVisible ? "translate-y-0 opacity-100" : "translate-y-8 opacity-0"
                }`}
                style={{
                  transitionDelay: `${index * 100}ms`,
                  transform: isVisible ? `translateY(${scrollY * 0.02 * ((index % 4) - 1.5)}px)` : "translateY(8px)",
                }}
              >
                <CardHeader className="p-0">
                  <div className="relative overflow-hidden rounded-t-lg">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      width={300}
                      height={300}
                      className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                      loading="lazy"
                    />
                    <Badge
                      className="absolute top-2 right-2"
                      variant={product.type === "digital" ? "secondary" : "default"}
                    >
                      {product.type === "digital" ? t("product.digital") : t("product.physical")}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-4">
                  <div className="flex items-center gap-1 mb-2">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" aria-hidden="true" />
                    <span className="text-sm text-gray-600">
                      {product.rating} ({product.reviews})
                    </span>
                  </div>
                  <CardTitle className="text-lg mb-2">{product.name}</CardTitle>
                  <p className="text-sm text-gray-600 mb-2">{product.category}</p>
                  <p className="text-2xl font-bold text-gray-900">{formatPrice(product.price)}</p>
                </CardContent>
                <CardFooter className="p-4 pt-0 flex gap-2">
                  <Button asChild className="flex-1">
                    <Link
                      href={`/products/${product.id}`}
                      aria-label={t("product.viewDetailsAriaLabel", { name: product.name })}
                    >
                      {t("product.viewDetails")}
                    </Link>
                  </Button>
                  <Button
                    size="icon"
                    variant="outline"
                    aria-label={t("product.addToCartAriaLabel", { name: product.name })}
                  >
                    <ShoppingCart className="h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Video Bölümü */}
      <section ref={videoRef} className="py-16 bg-gray-50 relative" aria-labelledby="video-section-heading">
        {/* Parallax decorative elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
          <div ref={parallaxRefs.video} className="absolute inset-0" style={getParallaxStyle(-0.08)}>
            <div className="absolute top-0 right-10 w-80 h-80 rounded-full bg-secondary/10 blur-3xl"></div>
            <div className="absolute -bottom-40 -left-20 w-96 h-96 rounded-full bg-primary/5 blur-3xl"></div>
          </div>
        </div>

        <div className="container mx-auto px-4 relative">
          <div className="text-center mb-12" style={getParallaxStyle(0.04)}>
            <h2 id="video-section-heading" className="text-3xl font-bold text-gray-900 mb-4">
              {t("homepage.leatherVideos")}
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">{t("homepage.leatherVideosDesc")}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredVideos.map((video, index) => (
              <Card
                key={video.id}
                className={`group hover:shadow-lg transition-all duration-700 transform cursor-pointer ${
                  isVideoVisible ? "translate-y-0 opacity-100" : "translate-y-8 opacity-0"
                }`}
                style={{
                  transitionDelay: `${index * 150}ms`,
                  transform: isVideoVisible
                    ? `translateY(${scrollY * 0.015 * ((index % 4) - 1.5)}px)`
                    : "translateY(8px)",
                }}
                onClick={() => handleVideoClick(index)}
                aria-label={t("video.watchVideoAriaLabel", { title: video.title })}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault()
                    handleVideoClick(index)
                  }
                }}
              >
                <CardHeader className="p-0">
                  <div className="relative overflow-hidden rounded-t-lg">
                    <Image
                      src={video.thumbnail || "/placeholder.svg"}
                      alt={video.title}
                      width={400}
                      height={300}
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                      loading="lazy"
                    />
                    {/* Play button overlay */}
                    <div className="absolute inset-0 bg-black/30 group-hover:bg-black/40 transition-colors flex items-center justify-center">
                      <div className="w-16 h-16 bg-white/90 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                        <Play className="h-8 w-8 text-gray-800 ml-1" aria-hidden="true" />
                      </div>
                    </div>
                    {/* Duration badge */}
                    <div className="absolute bottom-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-sm flex items-center gap-1">
                      <Clock className="h-3 w-3" aria-hidden="true" />
                      <span aria-label={t("video.durationAriaLabel", { duration: video.duration })}>
                        {video.duration}
                      </span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-4">
                  <CardTitle className="text-lg mb-2 line-clamp-2">{video.title}</CardTitle>
                  <p className="text-sm text-gray-600 mb-3 line-clamp-2">{video.description}</p>
                  <div className="flex items-center gap-1 text-sm text-gray-500">
                    <Eye className="h-4 w-4" aria-hidden="true" />
                    <span>
                      {video.views.toLocaleString()} {t("homepage.views")}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-8" style={getParallaxStyle(0.02)}>
            <Button size="lg" variant="outline" asChild>
              <Link href="/videos">{t("homepage.watchAllVideos")}</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Video Player Modal */}
      {currentVideo && (
        <VideoPlayerModal
          isOpen={isVideoModalOpen}
          onClose={handleCloseVideoModal}
          video={currentVideo}
          onNext={handleNextVideo}
          onPrevious={handlePreviousVideo}
          hasNext={selectedVideoIndex !== null && selectedVideoIndex < featuredVideos.length - 1}
          hasPrevious={selectedVideoIndex !== null && selectedVideoIndex > 0}
        />
      )}

      {/* Kategoriler */}
      <section ref={categoryRef} className="py-16 relative" aria-labelledby="categories-heading">
        {/* Parallax decorative elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
          <div ref={parallaxRefs.category} className="absolute inset-0" style={getParallaxStyle(-0.06)}>
            <div className="absolute -top-20 -left-20 w-72 h-72 rounded-full bg-secondary/5 blur-3xl"></div>
            <div className="absolute bottom-0 right-0 w-96 h-96 rounded-full bg-primary/5 blur-3xl"></div>
          </div>
        </div>

        <div className="container mx-auto px-4 relative">
          <div className="text-center mb-12" style={getParallaxStyle(0.03)}>
            <h2 id="categories-heading" className="text-3xl font-bold text-gray-900 mb-4">
              {t("homepage.shopByCategory")}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Link
              href="/products?category=bags"
              className="group"
              aria-label={t("homepage.categoryAriaLabel", { category: t("homepage.leatherBags") })}
            >
              <Card className="hover:shadow-lg transition-shadow" style={getParallaxStyle(0.02, -10)}>
                <CardContent className="p-6 text-center">
                  <Image
                    src="/placeholder.svg?height=200&width=200"
                    alt={t("homepage.leatherBags")}
                    width={200}
                    height={200}
                    className="mx-auto mb-4 rounded-lg"
                    loading="lazy"
                  />
                  <h3 className="text-xl font-semibold mb-2">{t("homepage.leatherBags")}</h3>
                  <p className="text-gray-600">{t("homepage.leatherBagsDesc")}</p>
                </CardContent>
              </Card>
            </Link>

            <Link
              href="/products?category=accessories"
              className="group"
              aria-label={t("homepage.categoryAriaLabel", { category: t("homepage.accessories") })}
            >
              <Card className="hover:shadow-lg transition-shadow" style={getParallaxStyle(0.04)}>
                <CardContent className="p-6 text-center">
                  <Image
                    src="/placeholder.svg?height=200&width=200"
                    alt={t("homepage.accessories")}
                    width={200}
                    height={200}
                    className="mx-auto mb-4 rounded-lg"
                    loading="lazy"
                  />
                  <h3 className="text-xl font-semibold mb-2">{t("homepage.accessories")}</h3>
                  <p className="text-gray-600">{t("homepage.accessoriesDesc")}</p>
                </CardContent>
              </Card>
            </Link>

            <Link
              href="/digital"
              className="group"
              aria-label={t("homepage.categoryAriaLabel", { category: t("homepage.digitalGuides") })}
            >
              <Card className="hover:shadow-lg transition-shadow" style={getParallaxStyle(0.02, 10)}>
                <CardContent className="p-6 text-center">
                  <Image
                    src="/placeholder.svg?height=200&width=200"
                    alt={t("homepage.digitalGuides")}
                    width={200}
                    height={200}
                    className="mx-auto mb-4 rounded-lg"
                    loading="lazy"
                  />
                  <h3 className="text-xl font-semibold mb-2">{t("homepage.digitalGuides")}</h3>
                  <p className="text-gray-600">{t("homepage.digitalGuidesDesc")}</p>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>
      </section>

      {/* Hakkımızda Bölümü */}
      <section ref={aboutRef} className="py-16 bg-gray-50 relative" aria-labelledby="about-heading">
        {/* Parallax decorative elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
          <div ref={parallaxRefs.about} className="absolute inset-0" style={getParallaxStyle(-0.07)}>
            <div className="absolute top-20 left-0 w-64 h-64 rounded-full bg-primary/5 blur-3xl"></div>
            <div className="absolute -bottom-20 right-10 w-80 h-80 rounded-full bg-secondary/5 blur-3xl"></div>
          </div>
        </div>

        <div className="container mx-auto px-4 relative">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12" style={getParallaxStyle(0.05)}>
              <h2 id="about-heading" className="text-3xl font-bold text-gray-900 mb-4">
                {t("homepage.ourCraft")}
              </h2>
              <p className="text-xl text-gray-600">{t("homepage.ourCraftSubtitle")}</p>
            </div>

            <div className="prose prose-lg max-w-none text-gray-700 leading-relaxed" style={getParallaxStyle(0.02)}>
              <p className="mb-6">
                Deri tasarımı ve üretimi, zanaatkarlık ve sanatı harmanlayan karmaşık bir süreçtir. Bu süreç, yüksek
                kaliteli deri malzemelerini seçme aşamasıyla başlar; her bir parça, hem estetik hem de dayanıklılık
                açısından titizlikle değerlendirilir. Deri, doğal bir hayvan ürünü olarak, benzersiz dokular ve desenler
                sunar, bu da her tasarımı kendine özgü kılar.
              </p>

              <p className="mb-6">
                Tasarım aşaması, yaratıcı güçlerin serbest bırakıldığı yerdir. Designerlar, fonksiyonellikle estetiği
                bir araya getirerek, zamansız ve özgün parçalar yaratır. Tasarımlar, hem geleneksel hem de modern ögeler
                içerebilir; bu da, deri üretiminde sınırların ötesine geçmeyi sağlar. Her parça, titizlikle planlanır,
                çizilir ve prototiplenir, bu süreçte mükemmeliyet arayışı asla unutulmaz.
              </p>

              <p className="mb-6">
                Üretim süreci, deri tasarımının ruhunu somutlaştırır. Usta zanaatlar, kesmeden dikişe kadar her aşamada
                becerilerini sergiler. Derinin doğru şekilde işlenmesi, hem kalitenin garanti altına alınması hem de
                sürdürülebilirliğin sağlanması açısından kritik öneme sahiptir. Ekolojik trendler, organik ve geri
                dönüştürülebilir malzemelere yönelerek modern deri üretim sürecini şekillendirmektedir.
              </p>

              <p className="mb-8">
                Sonuç olarak, deri tasarımı ve üretimi, süregeldiği tarih boyunca süregelen bir ustalık ve yaratıcılık
                serüvenidir. Her parça, hikayesini anlatır ve kullanıcısına sadece bir aksesuar değil, aynı zamanda
                zamansız bir değer sunar. Bu alandaki gelişmeler, geleneksel zanaatkarlığı modern tekniklerle bir araya
                getirerek, dingin ve şık bir yaşam tarzının vazgeçilmez unsurlarından biri haline gelir.
              </p>

              <div className="text-center" style={getParallaxStyle(0.03)}>
                <Button size="lg" asChild>
                  <Link href="/about" aria-label={t("homepage.discoverStoryAriaLabel")}>
                    {t("homepage.discoverStory")}
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
