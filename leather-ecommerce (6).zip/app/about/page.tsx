import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Award, Users, Clock, Leaf, Heart, Star, ArrowRight } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-amber-50 to-orange-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Deri Sanatının Ustalarıyız</h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              1985'ten beri geleneksel zanaatkarlığı modern tasarımla buluştururak, her parçada mükemmelliği
              hedefliyoruz.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Badge variant="secondary" className="text-lg px-4 py-2">
                <Award className="h-5 w-5 mr-2" />
                39 Yıl Deneyim
              </Badge>
              <Badge variant="secondary" className="text-lg px-4 py-2">
                <Users className="h-5 w-5 mr-2" />
                50,000+ Mutlu Müşteri
              </Badge>
              <Badge variant="secondary" className="text-lg px-4 py-2">
                <Star className="h-5 w-5 mr-2" />
                4.9/5 Müşteri Memnuniyeti
              </Badge>
            </div>
          </div>
        </div>
      </section>

      {/* Hikayemiz */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Hikayemiz</h2>
              <div className="prose prose-lg text-gray-700 space-y-4">
                <p>
                  DeriSanat, 1985 yılında İstanbul'da küçük bir atölyede başlayan tutkulu bir yolculuktur. Kurucumuz
                  Mehmet Usta, deri işçiliğine olan sevgisini ve ustalığını gelecek nesillere aktarma vizyonuyla bu
                  yolculuğa başladı.
                </p>
                <p>
                  Yıllar içinde, geleneksel el sanatlarını modern tasarım anlayışıyla harmanlayarak, deri sektöründe
                  kendine özgü bir yer edindik. Her ürünümüz, titizlikle seçilmiş malzemeler ve usta ellerin dokunuşuyla
                  hayat buluyor.
                </p>
                <p>
                  Bugün, 39 yıllık deneyimimizle, sadece Türkiye'de değil, dünya çapında kaliteli deri ürünlerin
                  temsilcisi olarak tanınıyoruz.
                </p>
              </div>
            </div>
            <div className="relative">
              <Image
                src="/placeholder.svg?height=500&width=600"
                alt="DeriSanat Atölyesi"
                width={600}
                height={500}
                className="rounded-lg shadow-lg"
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-lg shadow-lg">
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <span className="font-semibold">1985'ten beri</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Değerlerimiz */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Değerlerimiz</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Her ürünümüzde yansıttığımız temel değerler, kalite anlayışımızın temelidir.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="h-8 w-8 text-primary" />
                </div>
                <CardTitle>Kalite</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  En yüksek kaliteli malzemeler ve titiz işçilik anlayışı ile her ürünü özenle üretiyoruz.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Leaf className="h-8 w-8 text-green-600" />
                </div>
                <CardTitle>Sürdürülebilirlik</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Çevre dostu üretim süreçleri ve geri dönüştürülebilir malzemeler kullanıyoruz.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Heart className="h-8 w-8 text-red-600" />
                </div>
                <CardTitle>Tutku</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Deri sanatına olan tutkumuz, her ürünümüzde kendini gösterir ve fark yaratır.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
                <CardTitle>Müşteri Odaklılık</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Müşterilerimizin memnuniyeti ve güveni, tüm faaliyetlerimizin merkezindedir.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Üretim Süreci */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Üretim Sürecimiz</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Her ürünümüz, titizlikle planlanmış aşamalardan geçerek sizlere ulaşır.
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="prose prose-lg max-w-none text-gray-700 leading-relaxed mb-12">
              <p className="text-lg mb-6">
                Deri tasarımı ve üretimi, zanaatkarlık ve sanatı harmanlayan karmaşık bir süreçtir. Bu süreç, yüksek
                kaliteli deri malzemelerini seçme aşamasıyla başlar; her bir parça, hem estetik hem de dayanıklılık
                açısından titizlikle değerlendirilir. Deri, doğal bir hayvan ürünü olarak, benzersiz dokular ve desenler
                sunar, bu da her tasarımı kendine özgü kılar.
              </p>

              <p className="mb-6">
                Tasarım aşaması, yaratıcı güçlerin serbest bırakıldığı yerdir. Designerlar, fonksiyonellikle estetiği
                bir araya getirerek, zamansız ve özgün parçalar yaratır. Tasarımlar, hem geleneksel hem de modern ögeler
                içerebilir; bu da, deri üretiminde sınırların ötesine geçmeyi sağlar. Her parça, titizlikle planlanır,
                çizilir ve prototiplenir, bu süreçte mükemmeliyet arayışı asla unutulmaz.
              </p>

              <p className="mb-6">
                Üretim süreci, deri tasarımının ruhunu somutlaştırır. Usta zanaatlar, kesmeden dikişe kadar her aşamada
                becerilerini sergiler. Derinin doğru şekilde işlenmesi, hem kalitenin garanti altına alınması hem de
                sürdürülebilirliğin sağlanması açısından kritik öneme sahiptir. Ekolojik trendler, organik ve geri
                dönüştürülebilir malzemelere yönelerek modern deri üretim sürecini şekillendirmektedir.
              </p>

              <p className="mb-8">
                Sonuç olarak, deri tasarımı ve üretimi, süregeldiği tarih boyunca süregelen bir ustalık ve yaratıcılık
                serüvenidir. Her parça, hikayesini anlatır ve kullanıcısına sadece bir aksesuar değil, aynı zamanda
                zamansız bir değer sunar. Bu alandaki gelişmeler, geleneksel zanaatkarlığı modern tekniklerle bir araya
                getirerek, dingin ve şık bir yaşam tarzının vazgeçilmez unsurlarından biri haline gelir.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-amber-600">1</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">Malzeme Seçimi</h3>
                <p className="text-gray-600">En kaliteli deri malzemelerini titizlikle seçer ve değerlendiririz.</p>
              </div>

              <div className="text-center">
                <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-blue-600">2</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">Tasarım & Planlama</h3>
                <p className="text-gray-600">
                  Fonksiyonel ve estetik tasarımları özenle planlar ve prototipini oluştururuz.
                </p>
              </div>

              <div className="text-center">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-green-600">3</span>
                </div>
                <h3 className="text-xl font-semibold mb-2">Usta İşçilik</h3>
                <p className="text-gray-600">Deneyimli ustalarımız her ürünü el emeği ile titizlikle üretir.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Ekibimiz */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Ekibimiz</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Deneyimli ustalar ve yaratıcı tasarımcılardan oluşan ekibimizle, her üründe mükemmelliği hedefliyoruz.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-24 h-24 bg-gray-200 rounded-full mx-auto mb-4">
                  <Image
                    src="/placeholder.svg?height=96&width=96"
                    alt="Mehmet Usta"
                    width={96}
                    height={96}
                    className="rounded-full"
                  />
                </div>
                <h3 className="text-xl font-semibold mb-2">Mehmet Usta</h3>
                <p className="text-primary font-medium mb-2">Kurucu & Baş Usta</p>
                <p className="text-gray-600 text-sm">
                  39 yıllık deneyimi ile deri işçiliğinin tüm inceliklerini bilen ustamız.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-24 h-24 bg-gray-200 rounded-full mx-auto mb-4">
                  <Image
                    src="/placeholder.svg?height=96&width=96"
                    alt="Ayşe Hanım"
                    width={96}
                    height={96}
                    className="rounded-full"
                  />
                </div>
                <h3 className="text-xl font-semibold mb-2">Ayşe Hanım</h3>
                <p className="text-primary font-medium mb-2">Baş Tasarımcı</p>
                <p className="text-gray-600 text-sm">
                  Modern tasarım anlayışını geleneksel zanaatkarlıkla buluşturan yaratıcı tasarımcımız.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-24 h-24 bg-gray-200 rounded-full mx-auto mb-4">
                  <Image
                    src="/placeholder.svg?height=96&width=96"
                    alt="Ali Bey"
                    width={96}
                    height={96}
                    className="rounded-full"
                  />
                </div>
                <h3 className="text-xl font-semibold mb-2">Ali Bey</h3>
                <p className="text-primary font-medium mb-2">Kalite Kontrol Uzmanı</p>
                <p className="text-gray-600 text-sm">
                  Her ürünün en yüksek kalite standartlarında olmasını sağlayan deneyimli uzmanımız.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* İstatistikler */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-primary mb-2">39</div>
              <p className="text-gray-600">Yıl Deneyim</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">50K+</div>
              <p className="text-gray-600">Mutlu Müşteri</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">15</div>
              <p className="text-gray-600">Usta Zanaatkar</p>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">4.9</div>
              <p className="text-gray-600">Müşteri Puanı</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Kaliteli Deri Ürünlerini Keşfedin</h2>
          <p className="text-xl mb-8 opacity-90">
            39 yıllık deneyimimizle ürettiğimiz eşsiz deri ürünlerini inceleyin.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button size="lg" variant="secondary" asChild>
              <Link href="/products">
                Ürünleri İncele
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-white border-white hover:bg-white hover:text-primary"
              asChild
            >
              <Link href="/contact">İletişime Geç</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
