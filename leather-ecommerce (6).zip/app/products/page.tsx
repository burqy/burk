"use client"

import { useState, useMemo } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { ShoppingCart, Star, Filter } from "lucide-react"
import { useCart } from "@/components/cart-provider"
import { useToast } from "@/hooks/use-toast"
import { useLanguage } from "@/components/language-provider"

// Mock ürün verileri
const products = [
  {
    id: 1,
    name: "Premium Deri Cüzdan",
    price: 89.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "cüzdanlar",
    type: "physical" as const,
    rating: 4.8,
    reviews: 124,
    description: "Çoklu kart bölmeli el yapımı premium deri cüzdan",
  },
  {
    id: 2,
    name: "El Yapımı Deri Çanta",
    price: 249.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "çantalar",
    type: "physical" as const,
    rating: 4.9,
    reviews: 89,
    description: "İş ve seyahat için mükemmel geniş deri çanta",
  },
  {
    id: 3,
    name: "Deri Bakım Rehberi (PDF)",
    price: 9.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "dijital",
    type: "digital" as const,
    rating: 4.7,
    reviews: 256,
    description: "Deri bakımı ve korunması için kapsamlı rehber",
  },
  {
    id: 4,
    name: "Deri Kemer",
    price: 59.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "aksesuarlar",
    type: "physical" as const,
    rating: 4.6,
    reviews: 78,
    description: "Pirinç tokalı klasik deri kemer",
  },
  {
    id: 5,
    name: "Deri İşçiliği Eğitimi (PDF)",
    price: 19.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "dijital",
    type: "digital" as const,
    rating: 4.8,
    reviews: 145,
    description: "Yeni başlayanlar için adım adım deri işçiliği eğitimi",
  },
  {
    id: 6,
    name: "Yönetici Evrak Çantası",
    price: 399.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "çantalar",
    type: "physical" as const,
    rating: 4.9,
    reviews: 67,
    description: "Yöneticiler için profesyonel deri evrak çantası",
  },
  {
    id: 7,
    name: "Minimalist Deri Cüzdan",
    price: 49.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "cüzdanlar",
    type: "physical" as const,
    rating: 4.5,
    reviews: 156,
    description: "Günlük kullanım için mükemmel minimalist tasarım",
  },
  {
    id: 8,
    name: "RFID Korumalı Kart Tutucu",
    price: 29.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "kart-tutucular",
    type: "physical" as const,
    rating: 4.7,
    reviews: 203,
    description: "Modern yaşam için tasarlanmış RFID korumalı kart tutucu",
  },
  {
    id: 9,
    name: "Vintage Deri Cüzdan",
    price: 79.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "cüzdanlar",
    type: "physical" as const,
    rating: 4.8,
    reviews: 98,
    description: "Vintage tarzı seven erkekler için özel tasarım deri cüzdan",
  },
  {
    id: 10,
    name: "Kadın Deri Kart Tutucu",
    price: 35.99,
    image: "/placeholder.svg?height=300&width=300",
    category: "kart-tutucular",
    type: "physical" as const,
    rating: 4.6,
    reviews: 187,
    description: "Kadınlar için özel tasarlanmış şık kart tutucu",
  },
]

export default function ProductsPage() {
  const [sortBy, setSortBy] = useState("öne-çıkan")
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [selectedTypes, setSelectedTypes] = useState<string[]>([])
  const { addItem } = useCart()
  const { toast } = useToast()
  const { t, formatPrice } = useLanguage()

  const filteredProducts = useMemo(() => {
    let filtered = products

    // Kategoriye göre filtrele
    if (selectedCategories.length > 0) {
      filtered = filtered.filter((product) => selectedCategories.includes(product.category))
    }

    // Türe göre filtrele
    if (selectedTypes.length > 0) {
      filtered = filtered.filter((product) => selectedTypes.includes(product.type))
    }

    // Ürünleri sırala
    switch (sortBy) {
      case "fiyat-düşük":
        filtered.sort((a, b) => a.price - b.price)
        break
      case "fiyat-yüksek":
        filtered.sort((a, b) => b.price - a.price)
        break
      case "puan":
        filtered.sort((a, b) => b.rating - a.rating)
        break
      case "isim":
        filtered.sort((a, b) => a.name.localeCompare(b.name, "tr"))
        break
      default:
        // Öne çıkan - orijinal sırayı koru
        break
    }

    return filtered
  }, [selectedCategories, selectedTypes, sortBy])

  const handleCategoryChange = (category: string, checked: boolean) => {
    if (checked) {
      setSelectedCategories([...selectedCategories, category])
    } else {
      setSelectedCategories(selectedCategories.filter((c) => c !== category))
    }
  }

  const handleTypeChange = (type: string, checked: boolean) => {
    if (checked) {
      setSelectedTypes([...selectedTypes, type])
    } else {
      setSelectedTypes(selectedTypes.filter((t) => t !== type))
    }
  }

  const handleAddToCart = (product: (typeof products)[0]) => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      type: product.type,
    })
    toast({
      title: t("product.addedToCart"),
      description: `${product.name} sepetinize eklendi.`,
    })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Filtreler Kenar Çubuğu */}
        <div className="lg:w-64 space-y-6">
          <div className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            <h2 className="text-lg font-semibold">{t("common.filter")}</h2>
          </div>

          {/* Kategori Filtresi */}
          <div>
            <h3 className="font-medium mb-3">{t("product.category")}</h3>
            <div className="space-y-2">
              {["çantalar", "cüzdanlar", "kart-tutucular", "aksesuarlar", "dijital"].map((category) => (
                <div key={category} className="flex items-center space-x-2">
                  <Checkbox
                    id={category}
                    checked={selectedCategories.includes(category)}
                    onCheckedChange={(checked) => handleCategoryChange(category, checked as boolean)}
                  />
                  <Label htmlFor={category} className="capitalize">
                    {category === "kart-tutucular" ? "Kart Tutucular" : category}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          {/* Tür Filtresi */}
          <div>
            <h3 className="font-medium mb-3">{t("product.type")}</h3>
            <div className="space-y-2">
              {[
                { value: "physical", label: "Fiziksel" },
                { value: "digital", label: "Dijital" },
              ].map((type) => (
                <div key={type.value} className="flex items-center space-x-2">
                  <Checkbox
                    id={type.value}
                    checked={selectedTypes.includes(type.value)}
                    onCheckedChange={(checked) => handleTypeChange(type.value, checked as boolean)}
                  />
                  <Label htmlFor={type.value}>
                    {type.label === "Fiziksel" ? t("product.physical") : t("product.digital")}
                  </Label>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Ürün Listesi */}
        <div className="flex-1">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">
              {t("header.allProducts")} ({filteredProducts.length})
            </h1>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder={t("common.sort")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="öne-çıkan">Öne Çıkan</SelectItem>
                <SelectItem value="isim">İsim A-Z</SelectItem>
                <SelectItem value="fiyat-düşük">Fiyat: Düşükten Yükseğe</SelectItem>
                <SelectItem value="fiyat-yüksek">Fiyat: Yüksekten Düşüğe</SelectItem>
                <SelectItem value="puan">En Yüksek Puan</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product) => (
              <Card key={product.id} className="group hover:shadow-lg transition-shadow">
                <CardHeader className="p-0">
                  <div className="relative overflow-hidden rounded-t-lg">
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      width={300}
                      height={300}
                      className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <Badge
                      className="absolute top-2 right-2"
                      variant={product.type === "digital" ? "secondary" : "default"}
                    >
                      {product.type === "digital" ? "Dijital" : "Fiziksel"}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-4">
                  <div className="flex items-center gap-1 mb-2">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm text-gray-600">
                      {product.rating} ({product.reviews})
                    </span>
                  </div>
                  <CardTitle className="text-lg mb-2">{product.name}</CardTitle>
                  <p className="text-sm text-gray-600 mb-2">{product.description}</p>
                  <p className="text-2xl font-bold text-gray-900">{formatPrice(product.price)}</p>
                </CardContent>
                <CardFooter className="p-4 pt-0 flex gap-2">
                  <Button asChild className="flex-1">
                    <Link href={`/products/${product.id}`}>{t("product.viewDetails")}</Link>
                  </Button>
                  <Button size="icon" variant="outline" onClick={() => handleAddToCart(product)}>
                    <ShoppingCart className="h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
