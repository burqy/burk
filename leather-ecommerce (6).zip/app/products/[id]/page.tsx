"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Star, ShoppingCart, Shield, Truck, Gift, Lock, Eye, AlertTriangle } from "lucide-react"
import { useCart } from "@/components/cart-provider"
import { useAuth } from "@/components/auth-provider"
import { useToast } from "@/hooks/use-toast"
import { notFound } from "next/navigation"
import { useLanguage } from "@/components/language-provider"

// Gift wrapping options
const giftWrappingOptions = [
  {
    id: "none",
    name: "Hediye Paketi İstemiyorum",
    price: 0,
    description: "Standart ambalaj",
    image: "/placeholder.svg?height=100&width=100",
  },
  {
    id: "basic",
    name: "Temel Hediye Paketi",
    price: 5.99,
    description: "Şık hediye kutusu + kurdele",
    image: "/placeholder.svg?height=100&width=100",
  },
  {
    id: "premium",
    name: "Premium Hediye Paketi",
    price: 12.99,
    description: "Lüks kutu + saten kurdele + hediye kartı",
    image: "/placeholder.svg?height=100&width=100",
  },
  {
    id: "luxury",
    name: "Lüks Hediye Paketi",
    price: 19.99,
    description: "Özel tasarım kutu + altın kurdele + kişisel mesaj kartı + hediye torbası",
    image: "/placeholder.svg?height=100&width=100",
  },
]

const occasions = [
  "Doğum Günü",
  "Yıldönümü",
  "Sevgililer Günü",
  "Anneler Günü",
  "Babalar Günü",
  "Mezuniyet",
  "Yeni İş",
  "Düğün",
  "Nişan",
  "Yılbaşı",
  "Diğer",
]

// Mock product data - gerçek uygulamada bu veriler API'den gelecek
const products = [
  {
    id: 1,
    name: "Premium Deri Cüzdan",
    price: 89.99,
    images: [
      "/placeholder.svg?height=500&width=500",
      "/placeholder.svg?height=500&width=500",
      "/placeholder.svg?height=500&width=500",
    ],
    category: "cüzdanlar",
    type: "physical" as const,
    rating: 4.8,
    reviews: 124,
    description:
      "Çoklu kart bölmeli ve şık tasarımlı el yapımı premium deri cüzdan. Titizlikle işlenmiş gerçek İtalyan deriden üretilmiştir.",
    features: [
      "Gerçek İtalyan deri",
      "8 kart bölmesi",
      "2 banknot bölmesi",
      "RFID koruma teknolojisi",
      "El yapımı işçilik",
    ],
    specifications: {
      Malzeme: "İtalyan Deri",
      Boyutlar: "11.5cm x 9cm x 1.3cm",
      Ağırlık: "90g",
      Renk: "Kahverengi",
      Garanti: "2 yıl",
    },
    colorOptions: ["Kahverengi", "Siyah", "Koyu Kahverengi", "Kestane"],
    ropeColorOptions: ["Doğal", "Siyah", "Kahverengi", "Bej"],
    hasColorOptions: true,
    hasRopeOptions: true,
    giftWrappingAvailable: true,
  },
  {
    id: 2,
    name: "El Yapımı Deri Çanta",
    price: 249.99,
    images: [
      "/placeholder.svg?height=500&width=500",
      "/placeholder.svg?height=500&width=500",
      "/placeholder.svg?height=500&width=500",
    ],
    category: "çantalar",
    type: "physical" as const,
    rating: 4.9,
    reviews: 89,
    description:
      "İş ve seyahat için mükemmel geniş deri çanta. Dayanıklı malzemeden üretilmiş ve şık tasarımıyla her ortama uygun.",
    features: ["Premium deri malzeme", "Geniş iç hacim", "Çoklu bölme", "Ayarlanabilir askı", "Su geçirmez astar"],
    specifications: {
      Malzeme: "Premium Deri",
      Boyutlar: "40cm x 30cm x 15cm",
      Ağırlık: "800g",
      Renk: "Siyah",
      Garanti: "3 yıl",
    },
    colorOptions: ["Siyah", "Kahverengi", "Koyu Mavi", "Bordo"],
    ropeColorOptions: ["Siyah", "Kahverengi", "Doğal", "Gri"],
    hasColorOptions: true,
    hasRopeOptions: true,
    giftWrappingAvailable: true,
  },
  {
    id: 3,
    name: "Deri Bakım Rehberi (PDF)",
    price: 9.99,
    images: ["/placeholder.svg?height=500&width=500"],
    category: "dijital",
    type: "digital" as const,
    rating: 4.7,
    reviews: 256,
    description:
      "Deri bakımı ve korunması için kapsamlı dijital rehber. Deri ürünlerinizi yıllarca pristine durumda tutmak için profesyonel teknikler öğrenin.",
    features: [
      "50+ sayfa uzman tavsiyesi",
      "Adım adım bakım talimatları",
      "Ürün önerileri",
      "Sorun giderme rehberi",
      "Şifre korumalı PDF",
    ],
    specifications: {
      Format: "PDF",
      Sayfa: "52",
      "Dosya Boyutu": "15 MB",
      Dil: "Türkçe",
      Uyumluluk: "Tüm cihazlar",
      "İndirme Süresi": "30 gün",
    },
    hasColorOptions: false,
    hasRopeOptions: false,
    giftWrappingAvailable: false,
  },
  {
    id: 4,
    name: "Deri Kemer",
    price: 59.99,
    images: ["/placeholder.svg?height=500&width=500", "/placeholder.svg?height=500&width=500"],
    category: "aksesuarlar",
    type: "physical" as const,
    rating: 4.6,
    reviews: 78,
    description: "Pirinç tokalı klasik deri kemer. Günlük kullanım için dayanıklı ve şık tasarım.",
    features: ["Gerçek deri malzeme", "Pirinç toka", "Ayarlanabilir boyut", "Klasik tasarım", "Dayanıklı dikişler"],
    specifications: {
      Malzeme: "Gerçek Deri",
      Uzunluk: "120cm",
      Genişlik: "3.5cm",
      Renk: "Kahverengi",
      Garanti: "1 yıl",
    },
    colorOptions: ["Kahverengi", "Siyah", "Koyu Kahverengi"],
    ropeColorOptions: ["Doğal", "Siyah", "Kahverengi"],
    hasColorOptions: true,
    hasRopeOptions: true,
    giftWrappingAvailable: true,
  },
  {
    id: 5,
    name: "Deri İşçiliği Eğitimi (PDF)",
    price: 19.99,
    images: ["/placeholder.svg?height=500&width=500"],
    category: "dijital",
    type: "digital" as const,
    rating: 4.8,
    reviews: 145,
    description:
      "Yeni başlayanlar için adım adım deri işçiliği eğitimi. Temel tekniklerden ileri düzey uygulamalara kadar.",
    features: [
      "78 sayfa detaylı eğitim",
      "Adım adım fotoğraflar",
      "Araç gereç listesi",
      "Video bağlantıları",
      "Şifre korumalı PDF",
    ],
    specifications: {
      Format: "PDF",
      Sayfa: "78",
      "Dosya Boyutu": "25 MB",
      Dil: "Türkçe",
      Uyumluluk: "Tüm cihazlar",
      "İndirme Süresi": "30 gün",
    },
    hasColorOptions: false,
    hasRopeOptions: false,
    giftWrappingAvailable: false,
  },
  {
    id: 7,
    name: "Minimalist Deri Cüzdan",
    price: 49.99,
    images: ["/placeholder.svg?height=500&width=500", "/placeholder.svg?height=500&width=500"],
    category: "cüzdanlar",
    type: "physical" as const,
    rating: 4.5,
    reviews: 156,
    description: "Günlük kullanım için mükemmel minimalist tasarım. Kompakt boyutu ile ceplerinizde yer kaplamaz.",
    features: [
      "İnce ve hafif tasarım",
      "4 kart bölmesi",
      "1 banknot bölmesi",
      "Premium deri malzeme",
      "Minimalist görünüm",
    ],
    specifications: {
      Malzeme: "Premium Deri",
      Boyutlar: "10cm x 7cm x 0.8cm",
      Ağırlık: "45g",
      Renk: "Siyah",
      Garanti: "1 yıl",
    },
    colorOptions: ["Siyah", "Kahverengi", "Lacivert", "Gri"],
    ropeColorOptions: ["Doğal", "Siyah", "Kahverengi"],
    hasColorOptions: true,
    hasRopeOptions: true,
    giftWrappingAvailable: true,
  },
]

export default function ProductPage({ params }: { params: { id: string } }) {
  const productId = Number.parseInt(params.id)
  const product = products.find((p) => p.id === productId)
  const [selectedImage, setSelectedImage] = useState(0)
  const [selectedColor, setSelectedColor] = useState("")
  const [selectedRopeColor, setSelectedRopeColor] = useState("")
  const [selectedGiftWrap, setSelectedGiftWrap] = useState("none")
  const [giftOccasion, setGiftOccasion] = useState("")
  const [giftMessage, setGiftMessage] = useState("")
  const [isGift, setIsGift] = useState(false)
  const { addItem } = useCart()
  const { isAuthenticated } = useAuth()
  const { toast } = useToast()
  const { t, formatPrice } = useLanguage()

  if (!product) {
    notFound()
  }

  const selectedGiftOption = giftWrappingOptions.find((option) => option.id === selectedGiftWrap)
  const totalPrice = product.price + (selectedGiftOption?.price || 0)

  const handleAddToCart = () => {
    if (product.type === "digital" && !isAuthenticated) {
      toast({
        title: "Giriş Gerekli",
        description: "Dijital ürünleri satın almak için giriş yapmanız gerekiyor.",
        variant: "destructive",
      })
      return
    }

    const productVariant = {
      id: product.id,
      name: product.name,
      price: totalPrice,
      type: product.type,
      selectedColor: selectedColor || (product.colorOptions ? product.colorOptions[0] : ""),
      selectedRopeColor: selectedRopeColor || (product.ropeColorOptions ? product.ropeColorOptions[0] : ""),
      giftWrapping: selectedGiftOption,
      giftOccasion: giftOccasion,
      giftMessage: giftMessage,
      isGift: isGift,
    }

    addItem(productVariant)
    toast({
      title: "Sepete eklendi",
      description: `${product.name} sepetinize eklendi.`,
    })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
        {/* Product Images */}
        <div className="space-y-4">
          <div className="aspect-square overflow-hidden rounded-lg border relative">
            <Image
              src={product.images[selectedImage] || "/placeholder.svg"}
              alt={product.name}
              width={500}
              height={500}
              className="w-full h-full object-cover"
            />
            {product.type === "digital" && (
              <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                <div className="text-center text-white">
                  <Lock className="h-16 w-16 mx-auto mb-4" />
                  <p className="text-lg font-semibold">Korumalı İçerik</p>
                  <p className="text-sm">Satın alma sonrası erişilebilir</p>
                </div>
              </div>
            )}
          </div>
          {product.images.length > 1 && (
            <div className="flex gap-2">
              {product.images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(index)}
                  className={`w-20 h-20 rounded-lg border-2 overflow-hidden ${
                    selectedImage === index ? "border-primary" : "border-gray-200"
                  }`}
                >
                  <Image
                    src={image || "/placeholder.svg"}
                    alt={`${product.name} ${index + 1}`}
                    width={80}
                    height={80}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Product Info */}
        <div className="space-y-6">
          <div>
            <Badge variant={product.type === "digital" ? "secondary" : "default"} className="mb-2">
              {product.type === "digital" ? "Dijital Ürün" : "Fiziksel Ürün"}
            </Badge>
            <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
            <div className="flex items-center gap-2 mb-4">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${
                      i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
              <span className="text-sm text-gray-600">
                {product.rating} ({product.reviews} yorum)
              </span>
            </div>
            <div className="mb-4">
              <p className="text-4xl font-bold text-primary">{formatPrice(product.price)}</p>
              {selectedGiftOption && selectedGiftOption.price > 0 && (
                <p className="text-lg text-gray-600">
                  + Hediye Paketi: {formatPrice(selectedGiftOption.price)}
                  <span className="block text-2xl font-bold text-primary">Toplam: {formatPrice(totalPrice)}</span>
                </p>
              )}
            </div>
            <p className="text-gray-600 mb-6">{product.description}</p>
          </div>

          {/* Digital Product Security Notice */}
          {product.type === "digital" && (
            <Alert className="border-red-200 bg-red-50">
              <AlertTriangle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">
                <strong>Önemli:</strong> Bu dijital ürün telif hakkı koruması altındadır. Satın alma sonrası size özel
                şifre korumalı indirme bağlantısı gönderilecektir. İzinsiz paylaşım yasal işlem gerektirir.
              </AlertDescription>
            </Alert>
          )}

          {/* Authentication requirement for digital products */}
          {product.type === "digital" && !isAuthenticated && (
            <Alert className="border-blue-200 bg-blue-50">
              <Lock className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-800">
                Dijital ürünleri satın almak için <strong>giriş yapmanız</strong> gerekiyor. Bu, güvenli indirme
                bağlantısının doğru kişiye gönderilmesi için gereklidir.
              </AlertDescription>
            </Alert>
          )}

          {/* Color and Rope Options */}
          {(product.hasColorOptions || product.hasRopeOptions) && (
            <div className="space-y-4">
              {product.hasColorOptions && product.colorOptions && (
                <div>
                  <Label htmlFor="color" className="text-base font-medium mb-2 block">
                    {t("product.color")} {t("common.selection")}
                  </Label>
                  <Select value={selectedColor} onValueChange={setSelectedColor}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Renk seçiniz" />
                    </SelectTrigger>
                    <SelectContent>
                      {product.colorOptions.map((color) => (
                        <SelectItem key={color} value={color}>
                          {color}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {product.hasRopeOptions && product.ropeColorOptions && (
                <div>
                  <Label htmlFor="ropeColor" className="text-base font-medium mb-2 block">
                    {t("product.ropeColor")}
                  </Label>
                  <Select value={selectedRopeColor} onValueChange={setSelectedRopeColor}>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="İp rengi seçiniz" />
                    </SelectTrigger>
                    <SelectContent>
                      {product.ropeColorOptions.map((ropeColor) => (
                        <SelectItem key={ropeColor} value={ropeColor}>
                          {ropeColor}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
          )}

          {/* Gift Wrapping Options - Only for physical products */}
          {product.giftWrappingAvailable && product.type === "physical" && (
            <Card className="border-2 border-dashed border-orange-200 bg-orange-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-orange-800">
                  <Gift className="h-5 w-5" />
                  Hediye Paketi Seçenekleri
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Checkbox id="isGift" checked={isGift} onCheckedChange={setIsGift} />
                  <Label htmlFor="isGift" className="font-medium">
                    Bu ürün hediye olarak gönderilecek
                  </Label>
                </div>

                {isGift && (
                  <div className="space-y-4 pl-6 border-l-2 border-orange-200">
                    <div>
                      <Label className="text-base font-medium mb-3 block">Hediye Paketi Türü</Label>
                      <div className="grid grid-cols-1 gap-3">
                        {giftWrappingOptions.map((option) => (
                          <div
                            key={option.id}
                            className={`p-3 border rounded-lg cursor-pointer transition-all ${
                              selectedGiftWrap === option.id
                                ? "border-orange-500 bg-orange-100"
                                : "border-gray-200 hover:border-orange-300"
                            }`}
                            onClick={() => setSelectedGiftWrap(option.id)}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <Image
                                  src={option.image || "/placeholder.svg"}
                                  alt={option.name}
                                  width={40}
                                  height={40}
                                  className="rounded"
                                />
                                <div>
                                  <h4 className="font-medium">{option.name}</h4>
                                  <p className="text-sm text-gray-600">{option.description}</p>
                                </div>
                              </div>
                              <div className="text-right">
                                <p className="font-bold">{option.price === 0 ? "Ücretsiz" : `₺${option.price}`}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {selectedGiftWrap !== "none" && (
                      <>
                        <div>
                          <Label htmlFor="occasion" className="text-base font-medium mb-2 block">
                            Özel Gün (İsteğe Bağlı)
                          </Label>
                          <Select value={giftOccasion} onValueChange={setGiftOccasion}>
                            <SelectTrigger className="w-full">
                              <SelectValue placeholder="Özel gün seçiniz" />
                            </SelectTrigger>
                            <SelectContent>
                              {occasions.map((occasion) => (
                                <SelectItem key={occasion} value={occasion}>
                                  {occasion}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        {(selectedGiftWrap === "premium" || selectedGiftWrap === "luxury") && (
                          <div>
                            <Label htmlFor="giftMessage" className="text-base font-medium mb-2 block">
                              Hediye Mesajı {selectedGiftWrap === "luxury" && "(Kişisel Mesaj Kartı)"}
                            </Label>
                            <Textarea
                              id="giftMessage"
                              placeholder="Hediye mesajınızı buraya yazın... (maksimum 200 karakter)"
                              value={giftMessage}
                              onChange={(e) => setGiftMessage(e.target.value.slice(0, 200))}
                              className="min-h-[80px]"
                            />
                            <p className="text-sm text-gray-500 mt-1">{giftMessage.length}/200 karakter</p>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          <div className="space-y-4">
            <Button
              size="lg"
              className="w-full"
              onClick={handleAddToCart}
              disabled={product.type === "digital" && !isAuthenticated}
            >
              <ShoppingCart className="mr-2 h-5 w-5" />
              {product.type === "digital" && !isAuthenticated
                ? t("header.login")
                : `${t("product.addToCart")} - ${formatPrice(totalPrice)}`}
            </Button>

            {product.type === "digital" && (
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Lock className="h-4 w-4" />
                Satın alma sonrası güvenli indirme bağlantısı
              </div>
            )}
          </div>

          {/* Product Features */}
          <Card>
            <CardHeader>
              <CardTitle>Öne Çıkan Özellikler</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {product.features.map((feature, index) => (
                  <li key={index} className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-primary rounded-full" />
                    {feature}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          {/* Guarantees */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center gap-2 text-sm">
              <Shield className="h-5 w-5 text-green-600" />
              <span>Kalite Garantisi</span>
            </div>
            {product.type === "physical" ? (
              <div className="flex items-center gap-2 text-sm">
                <Truck className="h-5 w-5 text-blue-600" />
                <span>Ücretsiz Kargo</span>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-sm">
                <Lock className="h-5 w-5 text-red-600" />
                <span>Güvenli İndirme</span>
              </div>
            )}
            <div className="flex items-center gap-2 text-sm">
              {product.giftWrappingAvailable && product.type === "physical" ? (
                <>
                  <Gift className="h-5 w-5 text-purple-600" />
                  <span>Hediye Paketi Mevcut</span>
                </>
              ) : (
                <>
                  <Eye className="h-5 w-5 text-purple-600" />
                  <span>{product.type === "digital" ? "30 Gün Erişim" : "Hızlı Teslimat"}</span>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Product Details Tabs */}
      <Tabs defaultValue="specifications" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="specifications">Özellikler</TabsTrigger>
          <TabsTrigger value="reviews">Yorumlar</TabsTrigger>
          <TabsTrigger value="shipping">{product.type === "digital" ? "İndirme Bilgileri" : "Kargo"}</TabsTrigger>
          <TabsTrigger value="security">{product.type === "digital" ? "Güvenlik" : "Hediye Bilgileri"}</TabsTrigger>
        </TabsList>

        <TabsContent value="specifications" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Ürün Özellikleri</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.entries(product.specifications).map(([key, value]) => (
                  <div key={key} className="flex justify-between py-2 border-b">
                    <span className="font-medium">{key}:</span>
                    <span className="text-gray-600">{value}</span>
                  </div>
                ))}
                {product.hasColorOptions && (
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Mevcut Renkler:</span>
                    <span className="text-gray-600">{product.colorOptions?.join(", ")}</span>
                  </div>
                )}
                {product.hasRopeOptions && (
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">İp/Detay Renkleri:</span>
                    <span className="text-gray-600">{product.ropeColorOptions?.join(", ")}</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reviews" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Müşteri Yorumları</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="border-b pb-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <span className="font-medium">Ahmet K.</span>
                  </div>
                  <p className="text-gray-600">
                    {product.type === "digital"
                      ? "Çok detaylı ve faydalı bir rehber. İndirme işlemi sorunsuzdu."
                      : "Mükemmel kalite ve işçilik. Hediye paketi de çok şık olmuş!"}
                  </p>
                </div>
                <div className="border-b pb-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex">
                      {[...Array(4)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      ))}
                      <Star className="h-4 w-4 text-gray-300" />
                    </div>
                    <span className="font-medium">Zeynep M.</span>
                  </div>
                  <p className="text-gray-600">
                    {product.type === "digital"
                      ? "İçerik kaliteli ama biraz daha görsel olabilirdi."
                      : "Harika ürün, hızlı kargo. Premium hediye paketi gerçekten premium kalitede."}
                  </p>
                </div>
                <div className="border-b pb-4">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <span className="font-medium">Mehmet S.</span>
                  </div>
                  <p className="text-gray-600">
                    {product.type === "digital"
                      ? "Profesyonel içerik, paranın karşılığını veriyor. Tavsiye ederim."
                      : "Eşime hediye aldım, lüks hediye paketi ile birlikte çok beğendi. Tavsiye ederim."}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="shipping" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>{product.type === "digital" ? "İndirme Bilgileri" : "Kargo Bilgileri"}</CardTitle>
            </CardHeader>
            <CardContent>
              {product.type === "digital" ? (
                <div className="space-y-4">
                  <Alert className="border-blue-200 bg-blue-50">
                    <Lock className="h-4 w-4 text-blue-600" />
                    <AlertDescription className="text-blue-800">
                      <strong>Güvenli İndirme Süreci:</strong> Satın alma işleminiz tamamlandıktan sonra, size özel
                      şifre korumalı indirme bağlantısı e-postanıza gönderilecektir.
                    </AlertDescription>
                  </Alert>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    <li>İndirme bağlantısı satın alma sonrası 5 dakika içinde e-postanıza gelir</li>
                    <li>30 gün boyunca indirme erişimi</li>
                    <li>Şifre korumalı PDF dosyası</li>
                    <li>Tüm cihazlarla uyumlu</li>
                    <li>Kargo gerekmez - anında erişim</li>
                    <li>Hesap panelinizden tekrar indirme imkanı</li>
                  </ul>
                </div>
              ) : (
                <div className="space-y-4">
                  <p>Hızlı ve güvenilir kargo seçenekleri sunuyoruz:</p>
                  <ul className="list-disc list-inside space-y-2 text-gray-600">
                    <li>Ücretsiz standart kargo (5-7 iş günü)</li>
                    <li>Hızlı kargo mevcut (₺9.99, 2-3 iş günü)</li>
                    <li>Uluslararası kargo mevcut</li>
                    <li>Takip bilgisi sağlanır</li>
                  </ul>
                  <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-medium text-blue-900 mb-2">Özel Renk ve Hediye Siparişleri</h4>
                    <p className="text-blue-800 text-sm">
                      Seçtiğiniz renk kombinasyonu ve hediye paketi için ürün özel olarak hazırlanacaktır. Bu nedenle
                      teslimat süresi 1-2 iş günü daha uzayabilir.
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>
                {product.type === "digital" ? "Güvenlik ve Telif Hakkı" : "Hediye Paketi Bilgileri"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {product.type === "digital" ? (
                <div className="space-y-6">
                  <Alert className="border-red-200 bg-red-50">
                    <AlertTriangle className="h-4 w-4 text-red-600" />
                    <AlertDescription className="text-red-800">
                      <strong>Önemli Uyarı:</strong> Bu dijital ürün telif hakkı koruması altındadır. İzinsiz paylaşım,
                      çoğaltma veya dağıtım yasal işlem gerektirir.
                    </AlertDescription>
                  </Alert>

                  <div>
                    <h4 className="font-medium mb-3">Güvenlik Önlemleri</h4>
                    <ul className="list-disc list-inside space-y-1 text-gray-600 text-sm">
                      <li>Her satın alma için benzersiz şifre korumalı PDF</li>
                      <li>Kişiselleştirilmiş filigran ile koruma</li>
                      <li>İndirme bağlantıları 30 gün sonra otomatik olarak devre dışı kalır</li>
                      <li>Maksimum 5 cihazda açılabilir</li>
                      <li>Yazdırma koruması (sadece kişisel kullanım)</li>
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-medium mb-3">Kullanım Koşulları</h4>
                    <ul className="list-disc list-inside space-y-1 text-gray-600 text-sm">
                      <li>Sadece kişisel kullanım için</li>
                      <li>Ticari amaçlı kullanım yasaktır</li>
                      <li>İnternet üzerinden paylaşım yasaktır</li>
                      <li>Dosyayı başkalarına vermek yasaktır</li>
                      <li>İhlal durumunda yasal işlem başlatılır</li>
                    </ul>
                  </div>

                  <div className="bg-green-50 p-4 rounded-lg">
                    <h4 className="font-medium text-green-800 mb-2">Destek ve Yardım</h4>
                    <p className="text-green-700 text-sm">
                      İndirme veya dosya açma konusunda sorun yaşarsanız, 7/24 müşteri hizmetlerimizle iletişime
                      geçebilirsiniz. Size yeni indirme bağlantısı gönderebiliriz.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  <div>
                    <h4 className="font-medium mb-3">Hediye Paketi Seçeneklerimiz</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {giftWrappingOptions.slice(1).map((option) => (
                        <div key={option.id} className="border rounded-lg p-4">
                          <div className="flex items-center gap-3 mb-2">
                            <Image
                              src={option.image || "/placeholder.svg"}
                              alt={option.name}
                              width={50}
                              height={50}
                              className="rounded"
                            />
                            <div>
                              <h5 className="font-medium">{option.name}</h5>
                              <p className="text-lg font-bold text-primary">₺{option.price}</p>
                            </div>
                          </div>
                          <p className="text-sm text-gray-600">{option.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-orange-50 p-4 rounded-lg">
                    <h4 className="font-medium text-orange-800 mb-2">Hediye Hizmetleri</h4>
                    <ul className="list-disc list-inside space-y-1 text-orange-700 text-sm">
                      <li>Tüm hediye paketleri özenle el yapımı olarak hazırlanır</li>
                      <li>Kişisel mesaj kartları el yazısı ile yazılabilir</li>
                      <li>Özel günler için temaya uygun dekorasyon</li>
                      <li>Hediye makbuzu fatura yerine konulabilir</li>
                      <li>Farklı adrese teslimat imkanı</li>
                    </ul>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
